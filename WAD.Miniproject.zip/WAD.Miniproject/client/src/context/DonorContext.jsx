import React, { createContext, useContext, useState, useEffect } from 'react';

const DonorContext = createContext();

export function DonorProvider({ children }) {
  // Default authentic donor session (matches seeded demo donor)
  const [donorProfile, setDonorProfile] = useState(() => {
    const saved = localStorage.getItem('giveglow_donor');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return {
      name: 'Praveen Kumar',
      email: 'praveen.kumar@example.com',
      pan: 'ABCDE1234F',
      phone: '+91 98765 43210',
      address: '124 Indiranagar, Bengaluru, Karnataka - 560038'
    };
  });

  const [activeCampaign, setActiveCampaign] = useState(null);
  const [donationModalOpen, setDonationModalOpen] = useState(false);
  const [preselectedAmount, setPreselectedAmount] = useState(null);

  const [receiptModalOpen, setReceiptModalOpen] = useState(false);
  const [activeReceipt, setActiveReceipt] = useState(null);

  const [socialBadgeModalOpen, setSocialBadgeModalOpen] = useState(false);
  const [activeBadgeDonation, setActiveBadgeDonation] = useState(null);

  const [videoModalOpen, setVideoModalOpen] = useState(false);
  const [activeVideoMilestone, setActiveVideoMilestone] = useState(null);

  const [pledgeModalOpen, setPledgeModalOpen] = useState(false);
  const [pledgeCampaign, setPledgeCampaign] = useState(null);

  const [toast, setToast] = useState(null);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  useEffect(() => {
    localStorage.setItem('giveglow_donor', JSON.stringify(donorProfile));
  }, [donorProfile]);

  function showToast(message, type = 'success') {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  }

  function triggerDataRefresh() {
    setRefreshTrigger(prev => prev + 1);
  }

  function openDonationModal(campaign, presetAmt = null) {
    setActiveCampaign(campaign);
    setPreselectedAmount(presetAmt);
    setDonationModalOpen(true);
  }

  function openReceiptModal(receipt) {
    setActiveReceipt(receipt);
    setReceiptModalOpen(true);
  }

  function openSocialBadgeModal(donation) {
    setActiveBadgeDonation(donation);
    setSocialBadgeModalOpen(true);
  }

  function openVideoModal(milestone) {
    setActiveVideoMilestone(milestone);
    setVideoModalOpen(true);
  }

  function openPledgeModal(campaign) {
    setPledgeCampaign(campaign);
    setPledgeModalOpen(true);
  }

  return (
    <DonorContext.Provider
      value={{
        donorProfile,
        setDonorProfile,
        activeCampaign,
        setActiveCampaign,
        donationModalOpen,
        setDonationModalOpen,
        preselectedAmount,
        openDonationModal,
        receiptModalOpen,
        setReceiptModalOpen,
        activeReceipt,
        openReceiptModal,
        socialBadgeModalOpen,
        setSocialBadgeModalOpen,
        activeBadgeDonation,
        openSocialBadgeModal,
        videoModalOpen,
        setVideoModalOpen,
        activeVideoMilestone,
        openVideoModal,
        pledgeModalOpen,
        setPledgeModalOpen,
        pledgeCampaign,
        openPledgeModal,
        toast,
        showToast,
        refreshTrigger,
        triggerDataRefresh
      }}
    >
      {children}
    </DonorContext.Provider>
  );
}

export function useDonor() {
  const context = useContext(DonorContext);
  if (!context) {
    throw new Error('useDonor must be used within a DonorProvider');
  }
  return context;
}
