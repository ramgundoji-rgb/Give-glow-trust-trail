const API_BASE = '/api';

export async function fetchCampaigns({ category, search, page = 1, limit = 6 }) {
  const params = new URLSearchParams();
  if (category && category !== 'All') params.append('category', category);
  if (search) params.append('search', search);
  params.append('page', page);
  params.append('limit', limit);

  const res = await fetch(`${API_BASE}/campaigns?${params.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch campaigns');
  return res.json();
}

export async function fetchCampaignById(id) {
  const res = await fetch(`${API_BASE}/campaigns/${id}`);
  if (!res.ok) throw new Error(`Failed to fetch campaign ${id}`);
  return res.json();
}

export async function fetchPlatformStats() {
  const res = await fetch(`${API_BASE}/campaigns/stats`);
  if (!res.ok) throw new Error('Failed to fetch platform statistics');
  return res.json();
}

export async function submitDonation(donationData) {
  const res = await fetch(`${API_BASE}/donations`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(donationData)
  });
  const data = await res.json();
  if (!res.ok) {
    const errorMsg = data.errors ? data.errors.join('. ') : data.message || 'Donation failed';
    throw new Error(errorMsg);
  }
  return data;
}

export async function fetchDonorDonations(email, page = 1, limit = 10) {
  const params = new URLSearchParams();
  if (email) params.append('email', email);
  params.append('page', page);
  params.append('limit', limit);

  const res = await fetch(`${API_BASE}/donations?${params.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch donor donations');
  return res.json();
}

export async function fetchReceiptDetails(receiptNo) {
  const res = await fetch(`${API_BASE}/receipts/${receiptNo}`);
  if (!res.ok) throw new Error('Failed to fetch 80G receipt');
  return res.json();
}

export async function submitPledge(pledgeData) {
  const res = await fetch(`${API_BASE}/pledges`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(pledgeData)
  });
  const data = await res.json();
  if (!res.ok) {
    const errorMsg = data.errors ? data.errors.join('. ') : data.message || 'Failed to create pledge';
    throw new Error(errorMsg);
  }
  return data;
}

export async function fetchDonorPledges(email) {
  const params = new URLSearchParams();
  if (email) params.append('email', email);
  const res = await fetch(`${API_BASE}/pledges?${params.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch pledges');
  return res.json();
}

export async function cancelDonorPledge(pledgeId) {
  const res = await fetch(`${API_BASE}/pledges/${pledgeId}/cancel`, {
    method: 'PATCH'
  });
  if (!res.ok) throw new Error('Failed to cancel pledge');
  return res.json();
}
