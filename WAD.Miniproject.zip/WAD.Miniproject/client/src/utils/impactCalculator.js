export function calculateImpactEquivalency(amount, unitCost, unitName) {
  const amt = Number(amount) || 0;
  const cost = Number(unitCost) || 500;
  const unitsCount = Math.floor(amt / cost);
  const remainingAmt = amt % cost;

  let deliverableText = '';
  if (unitsCount > 0) {
    deliverableText = `${unitsCount} × ${unitName}`;
    if (remainingAmt > 0) {
      deliverableText += ` + ₹${remainingAmt} support logistics`;
    }
  } else {
    const fraction = ((amt / cost) * 100).toFixed(0);
    deliverableText = `${fraction}% of 1 ${unitName}`;
  }

  const livesImpacted = Math.max(1, unitsCount);

  // Exact 85% Field Goods, 10% Logistics, 5% Administration allocation
  const fieldGoodsAllocation = Math.round(amt * 0.85);
  const logisticsAllocation = Math.round(amt * 0.10);
  const adminAllocation = amt - fieldGoodsAllocation - logisticsAllocation;

  return {
    amount: amt,
    unitCost: cost,
    unitName,
    unitsCount,
    deliverableText,
    livesImpacted,
    breakdown: {
      fieldGoods: fieldGoodsAllocation,
      fieldGoodsPct: 85,
      logistics: logisticsAllocation,
      logisticsPct: 10,
      admin: adminAllocation,
      adminPct: 5
    }
  };
}
