import React, { useState, useEffect } from 'react';
import { DonorProvider, useDonor } from './context/DonorContext';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import CampaignExplorer from './components/CampaignExplorer';
import CampaignDetailModal from './components/CampaignDetailModal';
import DonationModal from './components/DonationModal';
import ReceiptModal from './components/ReceiptModal';
import SocialBadgeModal from './components/SocialBadgeModal';
import MilestoneVideoDigest from './components/MilestoneVideoDigest';
import RecurringPledgeModal from './components/RecurringPledgeModal';
import LiveImpactCalculator from './components/LiveImpactCalculator';
import DonorImpactPortfolio from './components/DonorImpactPortfolio';
import Toast from './components/Toast';
import Footer from './components/Footer';
import { fetchPlatformStats, fetchCampaignById } from './services/api';

function MainApp() {
  const [activeTab, setActiveTab] = useState('campaigns');
  const [stats, setStats] = useState(null);
  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const { refreshTrigger } = useDonor();

  useEffect(() => {
    fetchPlatformStats()
      .then((data) => setStats(data.stats))
      .catch((err) => console.error('Failed to load stats:', err));
  }, [refreshTrigger]);

  async function handleViewCampaignDetails(campaign) {
    try {
      const fullData = await fetchCampaignById(campaign.id);
      setSelectedCampaign(fullData.campaign);
    } catch (err) {
      console.error(err);
      setSelectedCampaign(campaign);
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Global Navigation */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Hero Section */}
      <Hero
        stats={stats}
        onExploreClick={() => {
          setActiveTab('campaigns');
          const el = document.getElementById('campaigns-section');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
        onCalculatorClick={() => {
          setActiveTab('calculator');
          window.scrollTo({ top: 300, behavior: 'smooth' });
        }}
      />

      {/* Main Tab Content */}
      <main className="flex-1">
        {activeTab === 'campaigns' && (
          <>
            <CampaignExplorer onViewDetails={handleViewCampaignDetails} />
            <LiveImpactCalculator />
          </>
        )}

        {activeTab === 'calculator' && (
          <>
            <LiveImpactCalculator />
            <CampaignExplorer onViewDetails={handleViewCampaignDetails} />
          </>
        )}

        {activeTab === 'portfolio' && (
          <DonorImpactPortfolio />
        )}
      </main>

      {/* Footer */}
      <Footer />

      {/* Modals */}
      <CampaignDetailModal
        campaign={selectedCampaign}
        onClose={() => setSelectedCampaign(null)}
      />

      <DonationModal />
      <ReceiptModal />
      <SocialBadgeModal />
      <MilestoneVideoDigest />
      <RecurringPledgeModal />
      <Toast />
    </div>
  );
}

export default function App() {
  return (
    <DonorProvider>
      <MainApp />
    </DonorProvider>
  );
}
