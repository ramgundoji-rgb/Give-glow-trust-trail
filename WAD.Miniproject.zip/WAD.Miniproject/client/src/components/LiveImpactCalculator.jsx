import React, { useState } from 'react';
import { Calculator, Sparkles, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { formatIndianCurrency } from '../utils/currency';
import { useDonor } from '../context/DonorContext';

const CAUSE_CALCULATIONS = [
  {
    id: 'camp-stem-girls',
    title: 'Rural Girl STEM Kits',
    unitName: 'Hands-On Science Lab Kits',
    unitCost: 500,
    impactMultiplier: 1,
    badge: 'Child Education'
  },
  {
    id: 'camp-slum-meals',
    title: 'Slum Child Mid-Day Meals',
    unitName: 'Warm Nutritious Lunch Meals',
    unitCost: 500,
    impactMultiplier: 30, // 30 meals for 1 month
    badge: 'Child Nutrition'
  },
  {
    id: 'camp-flood-relief',
    title: 'Flood Emergency Packs',
    unitName: 'Family Food & Clean Water Kits',
    unitCost: 1000,
    impactMultiplier: 1,
    badge: 'Disaster Relief'
  },
  {
    id: 'camp-stray-welfare',
    title: 'Stray Animal Rabies Vaccines',
    unitName: 'Vaccinated & Glowing Safety Collars',
    unitCost: 250,
    impactMultiplier: 1,
    badge: 'Animal Welfare'
  },
  {
    id: 'camp-rural-health',
    title: 'Mobile Tribal Clinic Tests',
    unitName: 'Full Family Health Checkup Kits',
    unitCost: 600,
    impactMultiplier: 1,
    badge: 'Rural Healthcare'
  },
  {
    id: 'camp-clean-water',
    title: 'Solar Clean RO Water',
    unitName: 'Households Supplied for 1 Year',
    unitCost: 1500,
    impactMultiplier: 1,
    badge: 'Clean Water'
  }
];

export default function LiveImpactCalculator() {
  const { openDonationModal } = useDonor();
  const [sliderAmount, setSliderAmount] = useState(2500);

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950 rounded-3xl p-6 sm:p-10 border border-slate-800 text-white shadow-2xl relative overflow-hidden">
        {/* Glow */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 blur-[100px] rounded-full pointer-events-none" />

        <div className="max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-bold border border-emerald-500/30">
            <Calculator className="w-3.5 h-3.5" />
            <span>Interactive Tangible Impact Simulator</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            See Exactly What Your Contribution Buys
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Drag the slider to see how your funds translate down to unit deliverables across all 6 causes, with 85% allocated directly into field goods.
          </p>
        </div>

        {/* Interactive Slider Controller */}
        <div className="my-8 max-w-2xl bg-slate-800/80 rounded-2xl p-5 border border-slate-700 backdrop-blur-sm space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400">Contribution Amount:</span>
            <span className="text-3xl font-black text-emerald-400">
              {formatIndianCurrency(sliderAmount)}
            </span>
          </div>

          <input
            type="range"
            min="500"
            max="25000"
            step="500"
            value={sliderAmount}
            onChange={(e) => setSliderAmount(Number(e.target.value))}
            className="w-full h-2.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-emerald-500"
          />

          <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
            <span>₹500</span>
            <span>₹5,000</span>
            <span>₹10,000</span>
            <span>₹25,000</span>
          </div>
        </div>

        {/* Simulated Deliverables Across All 6 Causes */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {CAUSE_CALCULATIONS.map((c) => {
            const units = Math.floor(sliderAmount / c.unitCost);
            const totalImpact = units * c.impactMultiplier;

            return (
              <div
                key={c.id}
                className="bg-slate-800/50 hover:bg-slate-800/90 border border-slate-700/80 rounded-2xl p-4 transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                      {c.badge}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      ₹{c.unitCost}/unit
                    </span>
                  </div>

                  <h4 className="font-bold text-sm text-white">{c.title}</h4>

                  <div className="mt-3 p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/20">
                    <div className="text-2xl font-black text-emerald-300">
                      {totalImpact.toLocaleString()}
                    </div>
                    <div className="text-xs font-medium text-slate-300 mt-0.5">
                      {c.unitName}
                    </div>
                  </div>
                </div>

                <div className="pt-3 mt-3 border-t border-slate-700/60 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">
                    Field Goods: <strong>{formatIndianCurrency(sliderAmount * 0.85)}</strong>
                  </span>
                  <span className="text-emerald-400 font-bold">80G Deductible</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
