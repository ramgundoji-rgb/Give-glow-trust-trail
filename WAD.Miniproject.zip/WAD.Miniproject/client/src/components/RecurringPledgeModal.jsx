import React, { useState } from 'react';
import { X, Repeat, ShieldCheck, Check, Sparkles, Loader2, ArrowRight } from 'lucide-react';
import { useDonor } from '../context/DonorContext';
import { submitPledge } from '../services/api';
import { formatIndianCurrency } from '../utils/currency';

export default function RecurringPledgeModal() {
  const { pledgeModalOpen, setPledgeModalOpen, pledgeCampaign, donorProfile, showToast, triggerDataRefresh } = useDonor();

  if (!pledgeModalOpen || !pledgeCampaign) return null;

  const [monthlyAmount, setMonthlyAmount] = useState(1000);
  const [customAmount, setCustomAmount] = useState('1000');
  const [paymentMethod, setPaymentMethod] = useState('UPI AutoPay');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  function handlePreset(amt) {
    setMonthlyAmount(amt);
    setCustomAmount(String(amt));
  }

  function handleCustomChange(val) {
    const clean = val.replace(/\D/g, '');
    setCustomAmount(clean);
    const num = Number(clean);
    if (!isNaN(num) && num > 0) {
      setMonthlyAmount(num);
    }
  }

  async function handleSubmitPledge(e) {
    e.preventDefault();
    setError(null);

    if (monthlyAmount < 100) {
      setError('Minimum monthly micro-pledge is ₹100.');
      return;
    }

    try {
      setLoading(true);
      await submitPledge({
        campaignId: pledgeCampaign.id,
        donorName: donorProfile.name,
        donorEmail: donorProfile.email,
        donorPan: donorProfile.pan,
        monthlyAmount,
        paymentMethod
      });

      showToast(`Monthly recurring pledge of ₹${monthlyAmount}/month activated!`);
      triggerDataRefresh();
      setPledgeModalOpen(false);
    } catch (err) {
      setError(err.message || 'Failed to activate monthly pledge.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-200 my-8 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-600 flex items-center justify-center text-white">
              <Repeat className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">
                Stretch Feature • Recurring Micro-Donation Pledge
              </span>
              <h3 className="text-sm sm:text-base font-extrabold text-slate-900 line-clamp-1">
                {pledgeCampaign.title}
              </h3>
            </div>
          </div>

          <button
            onClick={() => setPledgeModalOpen(false)}
            className="p-1.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-700 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmitPledge} className="p-5 sm:p-6 space-y-5">
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold">
              {error}
            </div>
          )}

          <p className="text-xs text-slate-600 leading-relaxed">
            Automated monthly recurring micro-sponsorships provide sustained long-term impact for student education, daily slum nutrition, and medical supplies. You can pause or cancel at any time.
          </p>

          {/* Monthly Tiers */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              Select Monthly Contribution Tier
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[500, 1000, 2500].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => handlePreset(amt)}
                  className={`p-3 rounded-xl border text-center transition ${
                    monthlyAmount === amt
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-2 ring-emerald-500'
                      : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="font-extrabold text-sm">{formatIndianCurrency(amt)}</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">/ month</div>
                </button>
              ))}
            </div>

            <div className="relative mt-2">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400 text-xs">₹</span>
              <input
                type="text"
                value={customAmount}
                onChange={(e) => handleCustomChange(e.target.value)}
                placeholder="Or custom monthly amount"
                className="w-full pl-8 pr-4 py-2 text-xs font-bold text-slate-900 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>
          </div>

          {/* Donor Info Confirmation */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1">
            <div className="font-bold text-slate-800">Sponsoring as: {donorProfile.name}</div>
            <div className="text-slate-500">Email: {donorProfile.email} • PAN: {donorProfile.pan}</div>
            <div className="text-[11px] text-emerald-700 font-semibold pt-1">
              ✓ Eligible for 50% Section 80G tax deductions with monthly compiled certificates.
            </div>
          </div>

          {/* AutoPay Method */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              Recurring Debit Method
            </label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {['UPI AutoPay (Recommended)', 'e-Mandate NetBanking'].map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setPaymentMethod(m)}
                  className={`p-2.5 rounded-xl border text-left font-semibold transition ${
                    paymentMethod === m
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-900'
                      : 'border-slate-200 bg-white text-slate-700'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs transition shadow-md shadow-emerald-600/30 flex items-center justify-center gap-1.5"
          >
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <span>Activate Monthly Pledge ({formatIndianCurrency(monthlyAmount)}/mo)</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
