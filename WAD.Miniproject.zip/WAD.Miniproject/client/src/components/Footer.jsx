import React from 'react';
import { Heart, ShieldCheck, CheckCircle2, Lock, FileText, ArrowUpRight } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-400 text-xs border-t border-slate-800 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand Info */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center text-white font-bold">
                <Heart className="w-5 h-5 fill-white" />
              </div>
              <span className="font-extrabold text-lg text-white tracking-tight">GiveGlow</span>
            </div>
            <p className="text-slate-400 leading-relaxed text-xs">
              TrustTrail: The verified, immutable donation tracking platform bridging donor skepticism with ground deliverable proof.
            </p>
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-800 text-emerald-400 text-[11px] font-semibold border border-slate-700">
              <ShieldCheck className="w-3.5 h-3.5" />
              80G Tax-Deductible Platform
            </div>
          </div>

          {/* Trust Guarantees */}
          <div className="space-y-2">
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">TrustTrail Standard</h4>
            <ul className="space-y-1.5 text-xs">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>85% Field Deliverables Ratio</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Cryptographic Fund Ledgers</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>GPS Geotagged Milestone Feeds</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Instant 80G Tax Certificates</span>
              </li>
            </ul>
          </div>

          {/* Architecture & Tech Stack */}
          <div className="space-y-2">
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">3-Tier Architecture</h4>
            <ul className="space-y-1.5 text-xs">
              <li><strong className="text-slate-200">Presentation:</strong> React 18, Tailwind CSS, Lucide</li>
              <li><strong className="text-slate-200">Application:</strong> Node.js & Express REST API</li>
              <li><strong className="text-slate-200">Database:</strong> SQLite with Atomic Transactions</li>
              <li><strong className="text-slate-200">Testing:</strong> Automated Jest Unit & API Suite</li>
            </ul>
          </div>

          {/* Tax Compliance */}
          <div className="space-y-2">
            <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">Tax Exemption Details</h4>
            <p className="text-slate-400 text-xs leading-relaxed">
              All partner NGOs are registered under Section 12A and approved under Section 80G of the Income Tax Act, 1961. Donors are issued formal digital certificates bearing unique QR verification codes for hassle-free tax filing.
            </p>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500">
          <p>© 2026 GiveGlow — TrustTrail Hackathon Edition. Built for 100% Transparency.</p>
          <div className="flex items-center gap-4 text-xs">
            <span className="flex items-center gap-1 text-emerald-400">
              <Lock className="w-3 h-3" />
              End-to-End Audited Pipeline
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
