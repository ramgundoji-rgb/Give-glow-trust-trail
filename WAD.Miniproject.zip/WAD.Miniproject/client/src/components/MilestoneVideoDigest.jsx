import React from 'react';
import { X, Video, ShieldCheck, MapPin, Users, Calendar, CheckCircle2 } from 'lucide-react';
import { useDonor } from '../context/DonorContext';

export default function MilestoneVideoDigest() {
  const { videoModalOpen, setVideoModalOpen, activeVideoMilestone } = useDonor();

  if (!videoModalOpen || !activeVideoMilestone) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-slate-900 rounded-3xl overflow-hidden shadow-2xl border border-slate-800 text-white">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-rose-600 flex items-center justify-center text-white">
              <Video className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400">
                Stretch Feature • Verified Field Worker Video Digest
              </span>
              <h3 className="text-sm sm:text-base font-bold text-white truncate max-w-md">
                {activeVideoMilestone.title}
              </h3>
            </div>
          </div>

          <button
            onClick={() => setVideoModalOpen(false)}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Player Container */}
        <div className="relative aspect-video bg-black flex items-center justify-center">
          <video
            src={activeVideoMilestone.video_url}
            controls
            autoPlay
            className="w-full h-full object-contain"
          >
            Your browser does not support the video tag.
          </video>
        </div>

        {/* Video Context & Ground Notes */}
        <div className="p-4 sm:p-5 space-y-3 bg-slate-900">
          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300">
            <span className="flex items-center gap-1 text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Verified On-Ground Footage
            </span>
            <span className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              {activeVideoMilestone.date}
            </span>
            <span className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-slate-400" />
              {activeVideoMilestone.location}
            </span>
            <span className="flex items-center gap-1 text-teal-300 font-semibold">
              <Users className="w-3.5 h-3.5" />
              {activeVideoMilestone.recipients_count} Students / Recipients
            </span>
          </div>

          <p className="text-xs text-slate-300 leading-relaxed">
            {activeVideoMilestone.description}
          </p>

          <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
            <span>Verified by: <strong className="text-slate-200">{activeVideoMilestone.verifier_name}</strong></span>
            <span className="font-mono text-emerald-400">GPS: {activeVideoMilestone.gps_coords}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
