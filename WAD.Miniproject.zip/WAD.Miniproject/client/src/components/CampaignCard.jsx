import React from 'react';
import { ShieldCheck, Users, Calendar, MapPin, ArrowRight, Sparkles, Repeat } from 'lucide-react';
import { formatIndianCurrency } from '../utils/currency';
import { useDonor } from '../context/DonorContext';

export default function CampaignCard({ campaign, onViewDetails }) {
  const { openDonationModal, openPledgeModal } = useDonor();

  const percentage = campaign.percentage || Math.min(100, Math.round((campaign.raised_amount / campaign.goal_amount) * 100));

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col group">
      {/* Campaign Image Banner */}
      <div className="relative h-48 overflow-hidden bg-slate-100">
        <img
          src={campaign.image_url}
          alt={campaign.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

        {/* Category Pill */}
        <div className="absolute top-3 left-3">
          <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-white/95 text-slate-800 shadow-sm backdrop-blur-sm">
            {campaign.category}
          </span>
        </div>

        {/* 80G Tax Tag */}
        <div className="absolute top-3 right-3">
          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-extrabold bg-emerald-600 text-white shadow-md">
            <ShieldCheck className="w-3 h-3" />
            80G TAX EXEMPT
          </span>
        </div>

        {/* Location & NGO Name */}
        <div className="absolute bottom-3 left-3 right-3 text-white">
          <div className="flex items-center gap-1 text-[11px] text-emerald-300 font-medium truncate">
            <MapPin className="w-3 h-3 flex-shrink-0" />
            <span>{campaign.location}</span>
          </div>
          <div className="text-xs font-semibold text-slate-100 truncate mt-0.5">
            By {campaign.ngo_name}
          </div>
        </div>
      </div>

      {/* Card Content Body */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        <div>
          <h3
            onClick={() => onViewDetails(campaign)}
            className="font-bold text-base text-slate-900 group-hover:text-emerald-600 transition cursor-pointer line-clamp-1"
          >
            {campaign.title}
          </h3>

          <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed">
            {campaign.description}
          </p>
        </div>

        {/* Tangible Impact Equivalency Badge */}
        <div className="bg-emerald-50/80 border border-emerald-100 rounded-xl p-2.5">
          <div className="flex items-center gap-1.5 text-[11px] font-bold text-emerald-800">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
            <span>Unit Impact: {formatIndianCurrency(campaign.unit_cost)} = 1 {campaign.unit_name}</span>
          </div>
        </div>

        {/* Progress Bar & Financials */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <div>
              <span className="font-extrabold text-sm text-slate-900">
                {formatIndianCurrency(campaign.raised_amount)}
              </span>
              <span className="text-[11px] text-slate-500 font-medium ml-1">
                raised of {formatIndianCurrency(campaign.goal_amount)}
              </span>
            </div>
            <span className="font-bold text-xs text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
              {percentage}% Funded
            </span>
          </div>

          {/* Animated Goal Progress Bar */}
          <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full transition-all duration-700 ease-out"
              style={{ width: `${Math.min(100, percentage)}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
            <span className="flex items-center gap-1 font-medium">
              <Users className="w-3.5 h-3.5 text-slate-400" />
              {campaign.donor_count} Donors
            </span>
            <span className="flex items-center gap-1 font-medium">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              Ends {campaign.deadline}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="pt-2 border-t border-slate-100 space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => openDonationModal(campaign)}
              className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs transition shadow-sm flex items-center justify-center gap-1"
            >
              Donate Now
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => onViewDetails(campaign)}
              className="w-full py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition flex items-center justify-center"
            >
              Audited Ledger & Proof
            </button>
          </div>

          {/* Monthly recurring micro-sponsorship shortcut */}
          <button
            onClick={() => openPledgeModal(campaign)}
            className="w-full py-1.5 px-3 rounded-lg border border-dashed border-emerald-300 hover:border-emerald-500 hover:bg-emerald-50/50 text-[11px] font-semibold text-emerald-700 transition flex items-center justify-center gap-1"
          >
            <Repeat className="w-3 h-3 text-emerald-600" />
            Sponsor Monthly (Recurring Micro-Pledge)
          </button>
        </div>
      </div>
    </div>
  );
}
