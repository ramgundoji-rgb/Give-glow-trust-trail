import React from 'react';
import { Calendar, MapPin, Users, CheckCircle, Video, ShieldCheck, ExternalLink } from 'lucide-react';
import { useDonor } from '../context/DonorContext';

export default function ImpactMilestoneFeed({ milestones }) {
  const { openVideoModal } = useDonor();

  if (!milestones || milestones.length === 0) {
    return (
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-8 text-center text-slate-500 text-xs">
        No photographic impact milestones recorded yet. Delivery updates are posted post-dispatch.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-600">
            Ground Proof Timeline
          </h4>
          <h3 className="text-lg font-extrabold text-slate-900 mt-0.5">
            Photographic Impact Milestone Feed
          </h3>
        </div>
        <span className="text-xs font-bold text-slate-500 bg-slate-100 px-3 py-1 rounded-full border border-slate-200">
          {milestones.length} Verified Field Updates
        </span>
      </div>

      {/* Vertical Timeline */}
      <div className="relative pl-6 sm:pl-8 border-l-2 border-emerald-500/30 space-y-8">
        {milestones.map((m, idx) => (
          <div key={m.id || idx} className="relative group">
            {/* Timeline Dot */}
            <div className="absolute -left-[31px] sm:-left-[39px] top-1.5 w-5 h-5 rounded-full bg-emerald-600 border-4 border-white shadow flex items-center justify-center text-white">
              <div className="w-1.5 h-1.5 rounded-full bg-white" />
            </div>

            {/* Milestone Card */}
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition">
              {/* Photo & Video Cover */}
              <div className="relative h-60 sm:h-72 bg-slate-100 overflow-hidden">
                <img
                  src={m.image_url}
                  alt={m.title}
                  className="w-full h-full object-cover group-hover:scale-102 transition duration-500"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />

                {/* Verification Badge */}
                <div className="absolute top-3 left-3">
                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-[11px] font-extrabold bg-emerald-600 text-white shadow-md">
                    <CheckCircle className="w-3.5 h-3.5" />
                    {m.verification_badge.replace(/_/g, ' ')}
                  </span>
                </div>

                {/* Video Digest Button (Stretch Feature) */}
                {m.video_url && (
                  <button
                    onClick={() => openVideoModal(m)}
                    className="absolute top-3 right-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold bg-white/90 hover:bg-white text-slate-900 shadow-md backdrop-blur-sm transition"
                  >
                    <Video className="w-3.5 h-3.5 text-rose-600 fill-rose-600" />
                    <span>Watch Field Video Digest</span>
                  </button>
                )}

                {/* Title & Metadata over image */}
                <div className="absolute bottom-3 left-4 right-4 text-white">
                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-200 mb-1">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                      {m.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                      {m.location}
                    </span>
                    {m.gps_coords && (
                      <span className="font-mono text-[10px] text-emerald-300 bg-black/40 px-2 py-0.5 rounded">
                        GPS: {m.gps_coords}
                      </span>
                    )}
                  </div>
                  <h4 className="text-base sm:text-lg font-bold text-white line-clamp-1">
                    {m.title}
                  </h4>
                </div>
              </div>

              {/* Text Description & Verifier Attestation */}
              <div className="p-4 sm:p-5 space-y-3">
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                  {m.description}
                </p>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 text-xs">
                  <div className="flex items-center gap-1.5 font-bold text-slate-800">
                    <Users className="w-4 h-4 text-emerald-600" />
                    <span>{m.recipients_count.toLocaleString()} Direct Beneficiaries Impacted</span>
                  </div>

                  <div className="flex items-center gap-1.5 text-slate-500">
                    <ShieldCheck className="w-4 h-4 text-teal-600" />
                    <span>Attested by: <strong className="text-slate-700">{m.verifier_name}</strong></span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
