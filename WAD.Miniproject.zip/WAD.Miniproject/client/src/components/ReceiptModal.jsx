import React, { useEffect, useState } from 'react';
import { X, Download, Printer, ShieldCheck, CheckCircle2, Award, QrCode } from 'lucide-react';
import QRCode from 'qrcode';
import jsPDF from 'jspdf';
import { useDonor } from '../context/DonorContext';
import { formatIndianCurrency } from '../utils/currency';
import { amountInWords } from '../utils/numberToWords';

export default function ReceiptModal() {
  const { receiptModalOpen, setReceiptModalOpen, activeReceipt, openSocialBadgeModal } = useDonor();
  const [qrDataUrl, setQrDataUrl] = useState('');

  useEffect(() => {
    if (activeReceipt) {
      const qrPayload = `GIVEGLOW-VERIFIED:receipt=${activeReceipt.receiptNo}&pan=${activeReceipt.donorPan || activeReceipt.donor?.pan}&amt=${activeReceipt.amount}&ngo=${encodeURIComponent(activeReceipt.ngoName || activeReceipt.campaign?.ngoName || 'Vigyan Pragati')}`;
      QRCode.toDataURL(qrPayload, { width: 160, margin: 1 })
        .then((url) => setQrDataUrl(url))
        .catch((err) => console.error('QR Gen error:', err));
    }
  }, [activeReceipt]);

  if (!receiptModalOpen || !activeReceipt) return null;

  const donorName = activeReceipt.donorName || activeReceipt.donor?.name || 'Praveen Kumar';
  const donorPan = activeReceipt.donorPan || activeReceipt.donor?.pan || 'ABCDE1234F';
  const donorEmail = activeReceipt.donorEmail || activeReceipt.donor?.email || 'praveen.kumar@example.com';
  const donorAddress = activeReceipt.donorAddress || activeReceipt.donor?.address || 'Resident of India';

  const ngoName = activeReceipt.ngoName || activeReceipt.campaign?.ngoName || 'Vigyan Pragati Foundation';
  const ngo80gReg = activeReceipt.ngo80gReg || activeReceipt.campaign?.ngo80gReg || 'AABTV4589PF20214';
  const ngoRegNo = activeReceipt.ngoRegNo || activeReceipt.campaign?.ngoRegNo || 'U80903KA2018NPL112345';
  const campaignTitle = activeReceipt.campaignTitle || activeReceipt.campaign?.title || 'Rural Girl STEM Education Drive';

  const amount = activeReceipt.amount;
  const words = activeReceipt.amountInWords || amountInWords(amount);
  const receiptNo = activeReceipt.receiptNo;
  const taxExemptionRef = activeReceipt.taxExemptionRef;
  const dateFormatted = new Date(activeReceipt.createdAt || Date.now()).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  // Export receipt as formal PDF
  function handleDownloadPDF() {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    // Outer border
    doc.setDrawColor(22, 163, 74);
    doc.setLineWidth(1.5);
    doc.rect(10, 10, 190, 277);

    // Inner subtle border
    doc.setDrawColor(200, 200, 200);
    doc.setLineWidth(0.5);
    doc.rect(12, 12, 186, 273);

    // Header Title
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.setTextColor(22, 163, 74);
    doc.text('DONATION CUM TAX EXEMPTION RECEIPT', 105, 25, { align: 'center' });

    doc.setFontSize(10);
    doc.setTextColor(80, 80, 80);
    doc.text('(Issued pursuant to Section 80G(5)(vi) of the Income Tax Act, 1961)', 105, 31, { align: 'center' });

    // NGO Information
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.setTextColor(15, 23, 42);
    doc.text(ngoName, 105, 42, { align: 'center' });

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(100, 100, 100);
    doc.text(`Registration No: ${ngoRegNo}  |  80G Order No: ${ngo80gReg}`, 105, 47, { align: 'center' });
    doc.text('GiveGlow TrustTrail Verified Philanthropic Partner', 105, 52, { align: 'center' });

    doc.setDrawColor(22, 163, 74);
    doc.setLineWidth(0.8);
    doc.line(20, 56, 190, 56);

    // Metadata Grid
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(50, 50, 50);
    doc.text(`Receipt Number: ${receiptNo}`, 20, 66);
    doc.text(`Date of Issue: ${dateFormatted}`, 130, 66);

    doc.text(`80G Exemption Ref: ${taxExemptionRef}`, 20, 74);
    doc.text(`Payment Status: SUCCESS (Verified)`, 130, 74);

    doc.setDrawColor(230, 230, 230);
    doc.setLineWidth(0.5);
    doc.line(20, 80, 190, 80);

    // Donor Details
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(22, 163, 74);
    doc.text('DONOR PARTICULARS', 20, 88);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(40, 40, 40);
    doc.text(`Name of Donor: ${donorName}`, 20, 96);
    doc.text(`Permanent Account Number (PAN): ${donorPan}`, 20, 104);
    doc.text(`Email Address: ${donorEmail}`, 20, 112);
    doc.text(`Address: ${donorAddress}`, 20, 120);

    doc.line(20, 126, 190, 126);

    // Contribution Details
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(22, 163, 74);
    doc.text('CONTRIBUTION DETAILS & IMPACT', 20, 134);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(40, 40, 40);
    doc.text(`Charitable Cause: ${campaignTitle}`, 20, 142);
    doc.text(`Amount Contributed: ₹${amount.toLocaleString('en-IN')}`, 20, 150);
    doc.setFont('helvetica', 'bold');
    doc.text(`Amount in Words: ${words}`, 20, 158);

    doc.setFont('helvetica', 'normal');
    doc.text(`Tangible Ground Deliverable: ${activeReceipt.impactSummary || '3 × Science Kit for 1 Girl'}`, 20, 166);

    // Fund allocation split
    doc.text('Fund Allocation Ratio: 85% Field Goods | 10% Logistics | 5% Administration', 20, 174);

    doc.line(20, 180, 190, 180);

    // Statutory Declaration
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(30, 30, 30);
    doc.text('STATUTORY DECLARATION UNDER SECTION 80G:', 20, 188);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(70, 70, 70);
    const statutory = 'This is to certify that the donation of ₹' + amount.toLocaleString('en-IN') + ' received from ' + donorName + ' (PAN: ' + donorPan + ') is eligible for 50% deduction under Section 80G of the Indian Income Tax Act, 1961. We further confirm that no personal benefit, goods, or services have been provided in return for this contribution.';
    const splitStatutory = doc.splitTextToSize(statutory, 170);
    doc.text(splitStatutory, 20, 195);

    // QR Verification & Seal
    if (qrDataUrl) {
      doc.addImage(qrDataUrl, 'PNG', 20, 215, 38, 38);
    }

    doc.setFontSize(8);
    doc.setTextColor(120, 120, 120);
    doc.text('Scan QR to verify authentic cryptographic', 63, 230);
    doc.text('tamper-proof record on GiveGlow TrustTrail', 63, 235);

    // Signature block
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(30, 30, 30);
    doc.text('For ' + ngoName, 135, 235);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.text('Authorized Finance Signatory', 135, 245);
    doc.text('TrustTrail Blockchain-Secured Seal', 135, 250);

    // Footer
    doc.setFontSize(8);
    doc.setTextColor(150, 150, 150);
    doc.text('Generated via GiveGlow TrustTrail Platform  •  https://giveglow.org', 105, 275, { align: 'center' });

    doc.save(`GiveGlow_80G_Receipt_${receiptNo}.pdf`);
  }

  function handlePrint() {
    window.print();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 my-8 overflow-hidden">
        {/* Header Bar */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-100 bg-slate-50 no-print">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <h3 className="text-sm sm:text-base font-extrabold text-slate-900">
              Official 80G Tax Exemption Certificate
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setReceiptModalOpen(false);
                openSocialBadgeModal(activeReceipt);
              }}
              className="px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-xs flex items-center gap-1 transition"
            >
              <Award className="w-3.5 h-3.5" />
              <span>Share Social Story</span>
            </button>

            <button
              onClick={() => setReceiptModalOpen(false)}
              className="p-1.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-700 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Formal Printable Receipt Certificate Body */}
        <div id="receipt-printable-area" className="p-6 sm:p-8 space-y-6 bg-white text-slate-900">
          {/* Certificate Letterhead */}
          <div className="text-center border-b-2 border-emerald-600 pb-5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-[11px] font-extrabold uppercase tracking-wider mb-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              Government of India • Income Tax Department
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {ngoName}
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              NGO Reg No: <strong className="text-slate-700">{ngoRegNo}</strong> | 80G Order No: <strong className="text-slate-700">{ngo80gReg}</strong>
            </p>
            <div className="text-xs font-bold text-emerald-700 mt-2">
              DONATION CUM TAX EXEMPTION CERTIFICATE (SECTION 80G)
            </div>
          </div>

          {/* Receipt Numbers & Reference */}
          <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl text-xs border border-slate-200/80">
            <div>
              <span className="text-slate-500">Receipt Number:</span>
              <div className="font-mono font-extrabold text-sm text-slate-900">{receiptNo}</div>
            </div>
            <div>
              <span className="text-slate-500">Date of Donation:</span>
              <div className="font-semibold text-slate-900">{dateFormatted}</div>
            </div>
            <div>
              <span className="text-slate-500">80G Reference Number:</span>
              <div className="font-mono font-semibold text-emerald-700">{taxExemptionRef}</div>
            </div>
            <div>
              <span className="text-slate-500">Payment Status:</span>
              <div className="font-bold text-emerald-600 flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> SUCCESS (Tamper-Proof)
              </div>
            </div>
          </div>

          {/* Donor Information */}
          <div className="space-y-1.5 text-xs">
            <div className="font-bold uppercase tracking-wider text-slate-500 text-[10px]">
              Donor Particulars:
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 p-3 rounded-xl border border-slate-200">
              <div>
                <span className="text-slate-500">Name:</span> <strong className="text-slate-900">{donorName}</strong>
              </div>
              <div>
                <span className="text-slate-500">PAN Card:</span> <strong className="font-mono text-slate-900">{donorPan}</strong>
              </div>
              <div>
                <span className="text-slate-500">Email:</span> <span className="text-slate-700">{donorEmail}</span>
              </div>
              <div>
                <span className="text-slate-500">Address:</span> <span className="text-slate-700">{donorAddress}</span>
              </div>
            </div>
          </div>

          {/* Financials & Impact Equivalency */}
          <div className="bg-emerald-50/60 border border-emerald-200 rounded-2xl p-4 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-slate-600 font-semibold">Total Amount Received:</span>
              <span className="font-black text-xl text-emerald-800">{formatIndianCurrency(amount)}</span>
            </div>

            <div>
              <span className="text-slate-600">Amount in Words: </span>
              <strong className="text-slate-900 font-serif italic">{words}</strong>
            </div>

            <div>
              <span className="text-slate-600">Cause Supported: </span>
              <strong className="text-slate-900">{campaignTitle}</strong>
            </div>

            <div>
              <span className="text-slate-600">Tangible Unit Deliverable: </span>
              <strong className="text-emerald-700">{activeReceipt.impactSummary}</strong>
            </div>
          </div>

          {/* Statutory 80G Clause */}
          <div className="text-[11px] text-slate-500 leading-relaxed bg-slate-50 p-3.5 rounded-xl border border-slate-200">
            <strong>Statutory Exemption Clause: </strong>
            Donations to {ngoName} are eligible for 50% tax deduction under Section 80G of the Indian Income Tax Act, 1961. This digital certificate bears an authentic verification hash pursuant to Rule 18AB. No commercial consideration was provided in exchange for this charitable contribution.
          </div>

          {/* QR Code and Digital Seal */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-xs">
            <div className="flex items-center gap-3">
              {qrDataUrl && (
                <img src={qrDataUrl} alt="80G Verification QR Code" className="w-16 h-16 rounded border border-slate-200" />
              )}
              <div className="text-[10px] text-slate-400">
                <div className="font-bold text-slate-700">Digital QR Verification</div>
                <div>Scan with camera to inspect verified ledger</div>
              </div>
            </div>

            <div className="text-right">
              <div className="font-bold text-slate-800">GiveGlow TrustTrail</div>
              <div className="text-[10px] text-emerald-600 font-semibold">Cryptographically Verified</div>
              <div className="text-[10px] text-slate-400">Authorized Digital Seal</div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-100 flex flex-wrap items-center justify-end gap-3 no-print">
          <button
            onClick={handlePrint}
            className="px-4 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-100 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition"
          >
            <Printer className="w-4 h-4" />
            <span>Print Certificate</span>
          </button>

          <button
            onClick={handleDownloadPDF}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-2 transition shadow-md shadow-emerald-600/20"
          >
            <Download className="w-4 h-4" />
            <span>Download Official 80G PDF</span>
          </button>
        </div>
      </div>
    </div>
  );
}
