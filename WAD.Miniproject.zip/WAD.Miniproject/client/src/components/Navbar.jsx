import React, { useState } from 'react';
import { ShieldCheck, Heart, User, Award, ExternalLink, Sparkles, Check } from 'lucide-react';
import { useDonor } from '../context/DonorContext';

export default function Navbar({ activeTab, setActiveTab }) {
  const { donorProfile, setDonorProfile, showToast } = useDonor();
  const [profileOpen, setProfileOpen] = useState(false);
  const [editingName, setEditingName] = useState(donorProfile.name);
  const [editingPan, setEditingPan] = useState(donorProfile.pan);
  const [editingEmail, setEditingEmail] = useState(donorProfile.email);

  function handleSaveProfile(e) {
    e.preventDefault();
    setDonorProfile(prev => ({
      ...prev,
      name: editingName.trim(),
      email: editingEmail.trim(),
      pan: editingPan.trim().toUpperCase()
    }));
    setProfileOpen(false);
    showToast('Donor profile updated successfully!');
  }

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Trust Badge */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('campaigns')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-white shadow-md shadow-emerald-500/20">
              <Heart className="w-6 h-6 fill-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-tight text-slate-900">
                  Give<span className="text-emerald-600">Glow</span>
                </span>
                <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  TrustTrail Verified
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium">100% Traceable Charitable Giving & 80G Tax Exemption</p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center gap-1">
            <button
              onClick={() => setActiveTab('campaigns')}
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition ${
                activeTab === 'campaigns'
                  ? 'bg-emerald-50 text-emerald-700'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Vetted Causes
            </button>

            <button
              onClick={() => setActiveTab('calculator')}
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition ${
                activeTab === 'calculator'
                  ? 'bg-emerald-50 text-emerald-700'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Impact Calculator
            </button>

            <button
              onClick={() => setActiveTab('portfolio')}
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition flex items-center gap-1.5 ${
                activeTab === 'portfolio'
                  ? 'bg-emerald-50 text-emerald-700'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Award className="w-4 h-4 text-emerald-600" />
              Donor Portfolio & Receipts
            </button>
          </nav>

          {/* Right Action: Donor Profile Pill */}
          <div className="relative">
            <button
              onClick={() => setProfileOpen(!profileOpen)}
              className="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-full border border-slate-200 bg-slate-50 hover:bg-slate-100 transition shadow-sm text-left"
            >
              <div className="w-7 h-7 rounded-full bg-emerald-600 text-white flex items-center justify-center text-xs font-bold">
                {donorProfile.name.charAt(0)}
              </div>
              <div className="hidden sm:block">
                <div className="text-xs font-bold text-slate-800 leading-tight">{donorProfile.name}</div>
                <div className="text-[10px] text-emerald-600 font-mono font-medium">PAN: {donorProfile.pan}</div>
              </div>
            </button>

            {/* Profile Dropdown / Quick Edit */}
            {profileOpen && (
              <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-2xl border border-slate-200 p-4 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">Active Donor Profile</span>
                  <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                    80G Eligible
                  </span>
                </div>

                <form onSubmit={handleSaveProfile} className="mt-3 space-y-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Full Legal Name</label>
                    <input
                      type="text"
                      value={editingName}
                      onChange={(e) => setEditingName(e.target.value)}
                      className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Email (for 80G Receipts)</label>
                    <input
                      type="email"
                      value={editingEmail}
                      onChange={(e) => setEditingEmail(e.target.value)}
                      className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Indian PAN Card Number</label>
                    <input
                      type="text"
                      value={editingPan}
                      onChange={(e) => setEditingPan(e.target.value.toUpperCase())}
                      maxLength={10}
                      className="w-full text-xs font-mono uppercase px-2.5 py-1.5 rounded-lg border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                      required
                    />
                    <p className="text-[10px] text-slate-400 mt-0.5">Required for Section 80G tax rebate under Income Tax Act.</p>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setProfileOpen(false)}
                      className="flex-1 py-1.5 text-xs font-semibold rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="flex-1 py-1.5 text-xs font-bold rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm"
                    >
                      Save Profile
                    </button>
                  </div>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
