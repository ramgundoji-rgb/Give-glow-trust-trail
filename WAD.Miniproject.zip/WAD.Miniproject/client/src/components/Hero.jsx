import React from 'react';
import { ShieldCheck, TrendingUp, Users, FileCheck2, ArrowRight, Sparkles, CheckCircle2 } from 'lucide-react';
import { formatIndianCurrency } from '../utils/currency';

export default function Hero({ stats, onExploreClick, onCalculatorClick }) {
  return (
    <div className="relative overflow-hidden bg-gradient-to-b from-emerald-950 via-slate-900 to-slate-950 text-white pt-12 pb-20 px-4 sm:px-6 lg:px-8">
      {/* Decorative backdrop glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[350px] bg-emerald-500/10 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>TrustTrail Protocol: Bridging Donor Hesitation with Ground Deliverables</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
            Trace Every Rupee to <br className="hidden sm:inline" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-200">
              Tangible Ground Impact.
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-300 font-normal leading-relaxed max-w-2xl mx-auto">
            No vague overheads. No black-box charities. Watch unit-level deliverables unfold with GPS geotagged photo milestones, cryptographic fund ledgers, and instant 80G tax certificates.
          </p>

          {/* Call to action buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <button
              onClick={onExploreClick}
              className="px-6 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm transition shadow-lg shadow-emerald-600/30 flex items-center gap-2"
            >
              Explore Vetted Causes
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onCalculatorClick}
              className="px-6 py-3 rounded-xl bg-slate-800/80 hover:bg-slate-700/80 text-slate-200 border border-slate-700 font-semibold text-sm transition"
            >
              Interactive Impact Calculator
            </button>
          </div>
        </div>

        {/* Live Aggregate Impact Counters */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-14 pt-8 border-t border-slate-800/80 max-w-5xl mx-auto">
          <div className="bg-slate-800/40 border border-slate-800 rounded-2xl p-4 text-center backdrop-blur-sm">
            <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400">
              {stats ? formatIndianCurrency(stats.totalRaised) : '₹20,95,000'}
            </div>
            <div className="text-xs font-medium text-slate-400 mt-1 flex items-center justify-center gap-1">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              Verified Funds Raised
            </div>
          </div>

          <div className="bg-slate-800/40 border border-slate-800 rounded-2xl p-4 text-center backdrop-blur-sm">
            <div className="text-2xl sm:text-3xl font-extrabold text-white">
              {stats ? stats.totalLivesImpacted.toLocaleString() + '+' : '4,200+'}
            </div>
            <div className="text-xs font-medium text-slate-400 mt-1 flex items-center justify-center gap-1">
              <Users className="w-3.5 h-3.5 text-teal-400" />
              Direct Beneficiaries Reached
            </div>
          </div>

          <div className="bg-slate-800/40 border border-slate-800 rounded-2xl p-4 text-center backdrop-blur-sm">
            <div className="text-2xl sm:text-3xl font-extrabold text-white">
              85% / 10% / 5%
            </div>
            <div className="text-xs font-medium text-slate-400 mt-1 flex items-center justify-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              Field / Logistics / Admin Split
            </div>
          </div>

          <div className="bg-slate-800/40 border border-slate-800 rounded-2xl p-4 text-center backdrop-blur-sm">
            <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400">
              100%
            </div>
            <div className="text-xs font-medium text-slate-400 mt-1 flex items-center justify-center gap-1">
              <FileCheck2 className="w-3.5 h-3.5 text-emerald-400" />
              Section 80G Tax Deductible
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
