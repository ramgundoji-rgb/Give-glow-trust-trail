import React from 'react';
import { CheckCircle2, AlertCircle, X } from 'lucide-react';
import { useDonor } from '../context/DonorContext';

export default function Toast() {
  const { toast } = useDonor();
  if (!toast) return null;

  const isSuccess = toast.type === 'success';

  return (
    <div className="fixed bottom-6 right-6 z-50 max-w-md animate-bounce-once shadow-2xl">
      <div
        className={`flex items-start gap-3 rounded-xl p-4 text-white ${
          isSuccess ? 'bg-emerald-600' : 'bg-rose-600'
        }`}
      >
        {isSuccess ? (
          <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5" />
        ) : (
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
        )}
        <div className="text-sm font-medium leading-relaxed">{toast.message}</div>
      </div>
    </div>
  );
}
