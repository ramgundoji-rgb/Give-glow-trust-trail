import React, { useRef, useEffect, useState } from 'react';
import { X, Download, Share2, Sparkles, ShieldCheck, Heart } from 'lucide-react';
import { useDonor } from '../context/DonorContext';
import { formatIndianCurrency } from '../utils/currency';

export default function SocialBadgeModal() {
  const { socialBadgeModalOpen, setSocialBadgeModalOpen, activeBadgeDonation } = useDonor();
  const canvasRef = useRef(null);
  const [downloadUrl, setDownloadUrl] = useState('');

  useEffect(() => {
    if (socialBadgeModalOpen && activeBadgeDonation) {
      renderStoryCanvas();
    }
  }, [socialBadgeModalOpen, activeBadgeDonation]);

  function renderStoryCanvas() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    // Instagram / LinkedIn Story Dimensions (1080 x 1920)
    canvas.width = 1080;
    canvas.height = 1920;

    // Gradient Background
    const grad = ctx.createLinearGradient(0, 0, 0, 1920);
    grad.addColorStop(0, '#064e3b');   // emerald 900
    grad.addColorStop(0.5, '#0f172a'); // slate 900
    grad.addColorStop(1, '#022c22');   // deep emerald 950
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 1080, 1920);

    // Decorative circle glow
    ctx.beginPath();
    ctx.arc(540, 500, 350, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(16, 185, 129, 0.12)';
    ctx.fill();

    // Top Platform Header
    ctx.font = 'bold 36px Inter, sans-serif';
    ctx.fillStyle = '#34d399';
    ctx.textAlign = 'center';
    ctx.fillText('GIVEGLOW  •  TRUSTTRAIL PROTOCOL', 540, 180);

    // Heart Icon Shield Badge
    ctx.beginPath();
    ctx.arc(540, 360, 90, 0, Math.PI * 2);
    ctx.fillStyle = '#059669';
    ctx.fill();

    ctx.font = 'bold 70px Inter, sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText('♥', 540, 385);

    // Main Punchy Story Header
    ctx.font = 'bold 64px Inter, sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText('VERIFIED IMPACT CREATOR', 540, 550);

    // Donor Name Card
    ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.roundRect(140, 620, 800, 320, 32);
    ctx.fill();
    ctx.strokeStyle = 'rgba(52, 211, 153, 0.3)';
    ctx.lineWidth = 2;
    ctx.stroke();

    const donorName = activeBadgeDonation.donor_name || activeBadgeDonation.donorName || 'Praveen Kumar';
    ctx.font = 'bold 52px Inter, sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(donorName, 540, 720);

    ctx.font = 'normal 32px Inter, sans-serif';
    ctx.fillStyle = '#94a3b8';
    ctx.fillText('has made an audited philanthropic contribution of', 540, 790);

    const amount = activeBadgeDonation.amount || 1500;
    ctx.font = 'bold 76px Inter, sans-serif';
    ctx.fillStyle = '#34d399';
    ctx.fillText(formatIndianCurrency(amount), 540, 890);

    // Tangible Ground Deliverable Box
    ctx.fillStyle = 'rgba(16, 185, 129, 0.15)';
    ctx.roundRect(140, 980, 800, 420, 32);
    ctx.fill();
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 3;
    ctx.stroke();

    ctx.font = 'bold 32px Inter, sans-serif';
    ctx.fillStyle = '#a7f3d0';
    ctx.fillText('TANGIBLE GROUND DELIVERABLE', 540, 1060);

    const impact = activeBadgeDonation.impact_summary || activeBadgeDonation.impactSummary || '3 × Science Kit for 1 Girl';
    ctx.font = 'bold 44px Inter, sans-serif';
    ctx.fillStyle = '#ffffff';
    wrapText(ctx, impact, 540, 1140, 720, 56);

    const cause = activeBadgeDonation.campaign_title || activeBadgeDonation.campaignTitle || 'Rural Girl STEM Education Drive';
    ctx.font = 'normal 30px Inter, sans-serif';
    ctx.fillStyle = '#cbd5e1';
    ctx.fillText('Campaign: ' + cause, 540, 1340);

    // 80G Tax Exemption & Verification Stamp
    ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.roundRect(140, 1440, 800, 240, 28);
    ctx.fill();

    ctx.font = 'bold 30px Inter, sans-serif';
    ctx.fillStyle = '#34d399';
    ctx.fillText('✓ 85% DIRECT FIELD GOODS RATIO ENFORCED', 540, 1520);

    ctx.font = 'normal 26px Inter, sans-serif';
    ctx.fillStyle = '#94a3b8';
    ctx.fillText('Section 80G Tax Exemption Certificate Verified', 540, 1580);
    ctx.fillText('Tamper-Proof Receipt: ' + (activeBadgeDonation.receipt_no || activeBadgeDonation.receiptNo || 'GG-80G-VERIFIED'), 540, 1630);

    // Call To Action Footer
    ctx.font = 'bold 32px Inter, sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText('Join the Movement for 100% Traceable Philanthropy', 540, 1780);
    ctx.font = 'normal 26px Inter, sans-serif';
    ctx.fillStyle = '#34d399';
    ctx.fillText('https://giveglow.org  •  #GiveGlowTrustTrail', 540, 1830);

    // Save as data URL
    setDownloadUrl(canvas.toDataURL('image/png'));
  }

  // Helper function to wrap text neatly on canvas
  function wrapText(ctx, text, x, y, maxWidth, lineHeight) {
    const words = text.split(' ');
    let line = '';
    let curY = y;

    for (let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + ' ';
      const metrics = ctx.measureText(testLine);
      const testWidth = metrics.width;
      if (testWidth > maxWidth && n > 0) {
        ctx.fillText(line.trim(), x, curY);
        line = words[n] + ' ';
        curY += lineHeight;
      } else {
        line = testLine;
      }
    }
    ctx.fillText(line.trim(), x, curY);
  }

  if (!socialBadgeModalOpen || !activeBadgeDonation) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 rounded-3xl shadow-2xl border border-slate-800 my-8 overflow-hidden text-white flex flex-col items-center">
        {/* Header */}
        <div className="w-full flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            <h3 className="font-extrabold text-sm sm:text-base text-white">
              Social Donor Recognition Story Badge
            </h3>
          </div>
          <button
            onClick={() => setSocialBadgeModalOpen(false)}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Canvas Preview */}
        <div className="p-5 flex flex-col items-center">
          <p className="text-xs text-slate-400 text-center mb-4">
            Custom-rendered high-res 1080x1920 Story Card celebrating your ground impact.
          </p>

          <div className="w-64 aspect-[9/16] rounded-2xl overflow-hidden shadow-2xl border-2 border-emerald-500/40">
            <canvas ref={canvasRef} className="w-full h-full object-cover" />
          </div>
        </div>

        {/* Download Action */}
        <div className="w-full p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between gap-3">
          <span className="text-[11px] text-slate-400">
            Optimized for Instagram, WhatsApp & LinkedIn
          </span>

          <a
            href={downloadUrl}
            download={`GiveGlow_Story_Badge_${Date.now()}.png`}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-2 transition shadow-lg shadow-emerald-600/30"
          >
            <Download className="w-4 h-4" />
            <span>Download Story PNG</span>
          </a>
        </div>
      </div>
    </div>
  );
}
