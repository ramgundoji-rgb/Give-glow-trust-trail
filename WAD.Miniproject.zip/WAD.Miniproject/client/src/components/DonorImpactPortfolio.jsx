import React, { useState, useEffect } from 'react';
import { Award, Heart, ShieldCheck, Download, Calendar, ExternalLink, Repeat, Trash2, Loader2, Sparkles, Share2 } from 'lucide-react';
import { useDonor } from '../context/DonorContext';
import { fetchDonorDonations, fetchDonorPledges, cancelDonorPledge } from '../services/api';
import { formatIndianCurrency } from '../utils/currency';
import Pagination from './Pagination';

export default function DonorImpactPortfolio() {
  const { donorProfile, openReceiptModal, openSocialBadgeModal, showToast, refreshTrigger, triggerDataRefresh } = useDonor();
  const [donations, setDonations] = useState([]);
  const [summary, setSummary] = useState(null);
  const [pledges, setPledges] = useState([]);
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPortfolioData();
  }, [donorProfile.email, page, refreshTrigger]);

  async function loadPortfolioData() {
    try {
      setLoading(true);
      const [donRes, plgRes] = await Promise.all([
        fetchDonorDonations(donorProfile.email, page, 8),
        fetchDonorPledges(donorProfile.email)
      ]);

      setDonations(donRes.donations || []);
      setSummary(donRes.portfolioSummary);
      setPagination(donRes.pagination);
      setPledges(plgRes.pledges || []);
    } catch (err) {
      console.error('Failed to load portfolio:', err);
    } finally {
      setLoading(false);
    }
  }

  async function handleCancelPledge(pledgeId) {
    if (!confirm('Are you sure you want to pause this monthly recurring pledge?')) return;
    try {
      await cancelDonorPledge(pledgeId);
      showToast('Monthly recurring pledge cancelled.');
      triggerDataRefresh();
    } catch (err) {
      showToast(err.message, 'error');
    }
  }

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <div className="mb-8">
        <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">
          Personal Philanthropic Ledger
        </span>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
          Donor Impact Portfolio & 80G Receipts
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Tracking every rupee contributed by <strong className="text-slate-800">{donorProfile.name}</strong> (PAN: {donorProfile.pan}).
        </p>
      </div>

      {/* Impact Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
            <Heart className="w-6 h-6 fill-emerald-600 text-emerald-600" />
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900">
              {summary ? formatIndianCurrency(summary.totalContributed) : '₹6,000'}
            </div>
            <div className="text-xs text-slate-500 font-medium">Lifetime Philanthropic Contribution</div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center font-bold">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900">
              {summary ? summary.causesSupported : 3} Vetted Causes
            </div>
            <div className="text-xs text-slate-500 font-medium">Distinct Charitable Foundations Backed</div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-black text-slate-900">
              {summary ? summary.estimatedLivesImpacted : 12}+ Lives
            </div>
            <div className="text-xs text-slate-500 font-medium">Direct Beneficiaries Supported on Ground</div>
          </div>
        </div>
      </div>

      {/* Active Monthly Micro-Pledges (Stretch Feature) */}
      {pledges && pledges.length > 0 && (
        <div className="mb-10 bg-gradient-to-r from-emerald-50/80 to-teal-50/80 border border-emerald-200 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Repeat className="w-4 h-4 text-emerald-700" />
              <h3 className="text-sm font-extrabold text-emerald-950 uppercase tracking-wider">
                Active Monthly Recurring Micro-Pledges
              </h3>
            </div>
            <span className="text-[11px] font-bold text-emerald-800 bg-white px-2.5 py-1 rounded-full border border-emerald-200">
              {pledges.filter(p => p.status === 'ACTIVE').length} Active Subscriptions
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {pledges.map((p) => (
              <div key={p.id} className="bg-white rounded-xl p-3.5 border border-emerald-200 shadow-sm flex items-center justify-between">
                <div>
                  <div className="font-bold text-xs text-slate-900">{p.campaign_title}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    <span className="font-extrabold text-emerald-700">{formatIndianCurrency(p.monthly_amount)}</span> / month via {p.payment_method}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    Next charge: {p.next_charge_date} • Status: <strong className={p.status === 'ACTIVE' ? 'text-emerald-600' : 'text-slate-400'}>{p.status}</strong>
                  </div>
                </div>

                {p.status === 'ACTIVE' && (
                  <button
                    onClick={() => handleCancelPledge(p.id)}
                    className="p-2 text-rose-500 hover:bg-rose-50 rounded-lg text-xs font-semibold flex items-center gap-1 transition"
                    title="Cancel monthly pledge"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Detailed Donation History Ledger Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="font-bold text-base text-slate-900">
              Donation History & Section 80G Receipts
            </h3>
            <p className="text-xs text-slate-500">
              Instant PDF downloads containing official NGO registration seals and PAN references.
            </p>
          </div>

          <div className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>100% Tax Deductible Receipts</span>
          </div>
        </div>

        {loading ? (
          <div className="py-16 text-center">
            <Loader2 className="w-7 h-7 text-emerald-600 animate-spin mx-auto mb-2" />
            <p className="text-xs text-slate-500">Loading donor portfolio from SQLite database...</p>
          </div>
        ) : donations.length === 0 ? (
          <div className="py-16 text-center text-slate-500 text-xs">
            No donations recorded under {donorProfile.email} yet. Make your first contribution today!
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Receipt & Date</th>
                  <th className="py-3 px-4">Charitable Cause</th>
                  <th className="py-3 px-4">Amount</th>
                  <th className="py-3 px-4">Tangible Ground Impact</th>
                  <th className="py-3 px-4">Payment</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {donations.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-3.5 px-4 font-mono">
                      <div className="font-bold text-slate-900">{d.receipt_no}</div>
                      <div className="text-[10px] text-slate-400 font-sans mt-0.5">{d.created_at}</div>
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-800">{d.campaign_title}</div>
                      <div className="text-[10px] text-slate-500">{d.ngo_name}</div>
                    </td>
                    <td className="py-3.5 px-4 font-black text-slate-900 text-sm">
                      {formatIndianCurrency(d.amount)}
                    </td>
                    <td className="py-3.5 px-4 text-emerald-800 font-medium">
                      {d.impact_summary}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                        {d.payment_method}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right space-x-1">
                      <button
                        onClick={() => openReceiptModal(d)}
                        className="px-2.5 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold text-[11px] inline-flex items-center gap-1 transition"
                        title="View & Download 80G Tax Exemption Receipt"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>80G Receipt</span>
                      </button>

                      <button
                        onClick={() => openSocialBadgeModal(d)}
                        className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] inline-flex items-center gap-1 transition"
                        title="Generate Social Story Card"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        <span>Story Card</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <Pagination
          pagination={pagination}
          onPageChange={(p) => setPage(p)}
        />
      </div>
    </section>
  );
}
