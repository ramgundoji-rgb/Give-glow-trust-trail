import React from 'react';
import { PieChart, ShieldCheck, FileText, CheckCircle2, Hash, Calendar, Building2 } from 'lucide-react';
import { formatIndianCurrency } from '../utils/currency';

export default function FundUtilizationLedger({ campaign, ledger }) {
  if (!campaign) return null;

  const fieldGoodsPct = campaign.field_goods_pct || 85;
  const logisticsPct = campaign.logistics_pct || 10;
  const adminPct = campaign.admin_pct || 5;

  return (
    <div className="space-y-6">
      {/* Header and Trust Statement */}
      <div className="bg-emerald-50/80 border border-emerald-200 rounded-2xl p-4 sm:p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-extrabold text-emerald-800 uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Immutable Fund Allocation Ledger</span>
            </div>
            <p className="text-xs text-slate-600 mt-1">
              GiveGlow strictly enforces that at least 85% of your donation is deployed directly into field goods and tangible equipment.
            </p>
          </div>
          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-bold bg-white text-emerald-700 border border-emerald-200 shadow-sm self-start sm:self-auto">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            Independent Audit Verified
          </span>
        </div>

        {/* Stacked Percentage Allocation Bar Visualizer */}
        <div className="mt-5 space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-slate-700">
            <span>Percentage Allocation Split</span>
            <span className="text-emerald-700 font-extrabold">85% Field / 10% Logistics / 5% Admin</span>
          </div>

          <div className="h-6 w-full rounded-xl overflow-hidden flex shadow-inner bg-slate-200">
            <div
              style={{ width: `${fieldGoodsPct}%` }}
              className="bg-emerald-600 text-white text-[10px] font-bold flex items-center justify-center transition-all duration-500"
              title={`Field Goods: ${fieldGoodsPct}%`}
            >
              Field Goods ({fieldGoodsPct}%)
            </div>
            <div
              style={{ width: `${logisticsPct}%` }}
              className="bg-teal-500 text-white text-[10px] font-bold flex items-center justify-center transition-all duration-500"
              title={`Logistics: ${logisticsPct}%`}
            >
              Logistics ({logisticsPct}%)
            </div>
            <div
              style={{ width: `${adminPct}%` }}
              className="bg-slate-500 text-white text-[10px] font-bold flex items-center justify-center transition-all duration-500"
              title={`Admin: ${adminPct}%`}
            >
              Admin ({adminPct}%)
            </div>
          </div>

          {/* Allocation Legend */}
          <div className="grid grid-cols-3 gap-2 pt-1 text-center text-[11px]">
            <div className="p-2 rounded-lg bg-emerald-100/60 text-emerald-900 font-semibold">
              <div className="font-extrabold text-sm">{fieldGoodsPct}%</div>
              <div>Direct Field Deliverables</div>
            </div>
            <div className="p-2 rounded-lg bg-teal-100/60 text-teal-900 font-semibold">
              <div className="font-extrabold text-sm">{logisticsPct}%</div>
              <div>Last-Mile Transport & Fuel</div>
            </div>
            <div className="p-2 rounded-lg bg-slate-100 text-slate-700 font-semibold">
              <div className="font-extrabold text-sm">{adminPct}%</div>
              <div>Audit & 80G Tax Compliance</div>
            </div>
          </div>
        </div>
      </div>

      {/* Itemized Line-Item Expenditure Table */}
      <div>
        <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-3 flex items-center gap-1.5">
          <FileText className="w-3.5 h-3.5 text-slate-400" />
          <span>Itemized Expenditure Breakdown & Invoices</span>
        </h4>

        {(!ledger || ledger.length === 0) ? (
          <p className="text-xs text-slate-500 italic">No ledger entries recorded yet.</p>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-slate-200 shadow-sm bg-white">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
                <tr>
                  <th className="py-2.5 px-3">Category</th>
                  <th className="py-2.5 px-3">Item / Deliverable Description</th>
                  <th className="py-2.5 px-3">Allocated</th>
                  <th className="py-2.5 px-3">Spent to Date</th>
                  <th className="py-2.5 px-3">Vendor / Recipient</th>
                  <th className="py-2.5 px-3">Invoice & Verification Hash</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {ledger.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/80 transition">
                    <td className="py-3 px-3">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                          item.category === 'Field Goods'
                            ? 'bg-emerald-100 text-emerald-800'
                            : item.category === 'Logistics'
                            ? 'bg-teal-100 text-teal-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {item.category}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-semibold text-slate-800">
                      {item.item_name}
                      <div className="text-[10px] text-slate-400 font-normal flex items-center gap-1 mt-0.5">
                        <Calendar className="w-3 h-3" /> Audited on {item.audit_date}
                      </div>
                    </td>
                    <td className="py-3 px-3 font-mono font-medium text-slate-600">
                      {formatIndianCurrency(item.allocated_amount)}
                    </td>
                    <td className="py-3 px-3 font-mono font-bold text-slate-900">
                      {formatIndianCurrency(item.spent_amount)}
                    </td>
                    <td className="py-3 px-3 text-slate-600">
                      <div className="flex items-center gap-1">
                        <Building2 className="w-3 h-3 text-slate-400 flex-shrink-0" />
                        <span className="truncate max-w-[160px]" title={item.vendor_recipient}>
                          {item.vendor_recipient}
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-600">
                      <div className="font-mono text-[11px] font-semibold text-slate-800">
                        {item.invoice_ref}
                      </div>
                      <div className="text-[9px] font-mono text-slate-400 truncate max-w-[140px]" title={item.verification_hash}>
                        hash: {item.verification_hash}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
