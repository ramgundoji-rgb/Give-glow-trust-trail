import React, { useState } from 'react';
import { X, ShieldCheck, MapPin, Users, Calendar, ArrowRight, Repeat, Sparkles, PieChart, Image } from 'lucide-react';
import { useDonor } from '../context/DonorContext';
import { formatIndianCurrency } from '../utils/currency';
import FundUtilizationLedger from './FundUtilizationLedger';
import ImpactMilestoneFeed from './ImpactMilestoneFeed';

export default function CampaignDetailModal({ campaign, onClose }) {
  const { openDonationModal, openPledgeModal } = useDonor();
  const [activeTab, setActiveTab] = useState('overview');

  if (!campaign) return null;

  const percentage = campaign.percentage || Math.min(100, Math.round((campaign.raised_amount / campaign.goal_amount) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl border border-slate-200 my-8 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="relative h-64 sm:h-72 bg-slate-900 flex-shrink-0">
          <img
            src={campaign.image_url}
            alt={campaign.title}
            className="w-full h-full object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

          {/* Close button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-black/50 hover:bg-black/80 text-white backdrop-blur-sm transition"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Tags */}
          <div className="absolute top-4 left-4 flex gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-white text-slate-800 shadow">
              {campaign.category}
            </span>
            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-600 text-white shadow">
              <ShieldCheck className="w-3.5 h-3.5" />
              80G Certified
            </span>
          </div>

          {/* Title & Metadata */}
          <div className="absolute bottom-4 left-4 right-4 text-white">
            <div className="flex items-center gap-2 text-xs text-emerald-300 mb-1">
              <MapPin className="w-3.5 h-3.5" />
              <span>{campaign.location}</span>
              <span>•</span>
              <span>NGO: {campaign.ngo_name}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white leading-tight">
              {campaign.title}
            </h2>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center border-b border-slate-200 bg-slate-50 px-6 gap-2 flex-shrink-0">
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-3 px-3 text-xs font-bold border-b-2 transition ${
              activeTab === 'overview'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Campaign Story & Need
          </button>

          <button
            onClick={() => setActiveTab('ledger')}
            className={`py-3 px-3 text-xs font-bold border-b-2 transition flex items-center gap-1.5 ${
              activeTab === 'ledger'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <PieChart className="w-3.5 h-3.5 text-emerald-600" />
            Transparent Fund Ledger (85/10/5)
          </button>

          <button
            onClick={() => setActiveTab('milestones')}
            className={`py-3 px-3 text-xs font-bold border-b-2 transition flex items-center gap-1.5 ${
              activeTab === 'milestones'
                ? 'border-emerald-600 text-emerald-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Image className="w-3.5 h-3.5 text-teal-600" />
            Ground Proof Updates ({campaign.milestones?.length || 0})
          </button>
        </div>

        {/* Tab Content Body (Scrollable) */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Financial Progress Banner */}
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <div>
                    <span className="font-extrabold text-lg text-slate-900">
                      {formatIndianCurrency(campaign.raised_amount)}
                    </span>
                    <span className="text-slate-500 font-medium ml-1">
                      raised of {formatIndianCurrency(campaign.goal_amount)} goal
                    </span>
                  </div>
                  <span className="font-extrabold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                    {percentage}% Completed
                  </span>
                </div>

                <div className="w-full h-3 bg-slate-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full"
                    style={{ width: `${Math.min(100, percentage)}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                  <span className="flex items-center gap-1 font-semibold text-slate-700">
                    <Users className="w-4 h-4 text-emerald-600" />
                    {campaign.donor_count} Donors Backed
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4 text-slate-400" />
                    Target Deadline: {campaign.deadline}
                  </span>
                </div>
              </div>

              {/* Tangible Impact Equivalency Presets */}
              <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 mb-2">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <span>Tangible Unit Deliverables for this Cause:</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {campaign.tiers && campaign.tiers.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => {
                        onClose();
                        openDonationModal(campaign, t.amount);
                      }}
                      className="p-3 rounded-xl border border-emerald-200 bg-white text-left hover:border-emerald-500 hover:shadow-sm transition"
                    >
                      <div className="font-bold text-emerald-700 text-sm">{formatIndianCurrency(t.amount)}</div>
                      <div className="text-xs font-semibold text-slate-800 mt-0.5">{t.label}</div>
                      <div className="text-[10px] text-slate-500 mt-0.5">{t.impact_desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Story & Context */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Background Story & Beneficiaries
                </h4>
                <p className="text-sm text-slate-700 leading-relaxed">
                  {campaign.story || campaign.description}
                </p>
                <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1">
                  <div><strong>Primary Beneficiaries:</strong> {campaign.beneficiary_type}</div>
                  <div><strong>Implementing NGO:</strong> {campaign.ngo_name} (Reg: {campaign.ngo_reg_no})</div>
                  <div><strong>Tax Exemption Status:</strong> Approved under Section 80G ({campaign.ngo_80g_reg})</div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'ledger' && (
            <FundUtilizationLedger
              campaign={campaign}
              ledger={campaign.ledger}
            />
          )}

          {activeTab === 'milestones' && (
            <ImpactMilestoneFeed
              milestones={campaign.milestones}
            />
          )}
        </div>

        {/* Modal Action Footer */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 flex-shrink-0">
          <button
            onClick={() => {
              onClose();
              openPledgeModal(campaign);
            }}
            className="px-4 py-2.5 rounded-xl border border-emerald-300 hover:bg-emerald-50 text-emerald-700 font-bold text-xs flex items-center gap-1.5 transition"
          >
            <Repeat className="w-4 h-4" />
            <span>Monthly Micro-Pledge</span>
          </button>

          <button
            onClick={() => {
              onClose();
              openDonationModal(campaign);
            }}
            className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs flex items-center gap-2 transition shadow-lg shadow-emerald-600/30"
          >
            <span>Contribute to this Cause</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
