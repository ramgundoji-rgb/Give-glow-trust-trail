import React, { useState, useEffect } from 'react';
import { Search, Filter, Loader2, RefreshCw } from 'lucide-react';
import CampaignCard from './CampaignCard';
import Pagination from './Pagination';
import { fetchCampaigns } from '../services/api';
import { useDonor } from '../context/DonorContext';

const CATEGORIES = [
  'All',
  'Child Education',
  'Child Nutrition',
  'Disaster Relief',
  'Animal Welfare',
  'Rural Healthcare',
  'Clean Water'
];

export default function CampaignExplorer({ onViewDetails }) {
  const { refreshTrigger } = useDonor();
  const [campaigns, setCampaigns] = useState([]);
  const [category, setCategory] = useState('All');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    loadCampaigns();
  }, [category, page, refreshTrigger]);

  // Debounced search effect
  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(1);
      loadCampaigns();
    }, 300);
    return () => clearTimeout(timer);
  }, [search]);

  async function loadCampaigns() {
    try {
      setLoading(true);
      setError(null);
      const data = await fetchCampaigns({ category, search, page, limit: 6 });
      setCampaigns(data.campaigns || []);
      setPagination(data.pagination);
    } catch (err) {
      setError(err.message || 'Failed to load campaigns');
    } finally {
      setLoading(false);
    }
  }

  return (
    <section id="campaigns-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">
            Vetted Charitable Causes
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
            Active Verified Campaigns
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-xl">
            Every cause features verified 85/10/5 fund allocation formulas, third-party audit invoices, and photographic impact milestones.
          </p>
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search campaigns, causes, or locations..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl border border-slate-200 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-sm"
          />
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-4 scrollbar-none mb-6">
        <Filter className="w-3.5 h-3.5 text-slate-400 flex-shrink-0 ml-1" />
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            onClick={() => {
              setCategory(cat);
              setPage(1);
            }}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition ${
              category === cat
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Campaign Cards Grid */}
      {loading ? (
        <div className="flex flex-col items-center justify-center py-20">
          <Loader2 className="w-8 h-8 text-emerald-600 animate-spin mb-3" />
          <p className="text-xs font-medium text-slate-500">Loading verified campaigns from SQLite ledger...</p>
        </div>
      ) : error ? (
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-6 text-center max-w-md mx-auto">
          <p className="text-sm font-semibold text-rose-700">{error}</p>
          <button
            onClick={loadCampaigns}
            className="mt-3 px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold inline-flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Retry
          </button>
        </div>
      ) : campaigns.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center max-w-md mx-auto">
          <p className="text-sm font-semibold text-slate-700">No campaigns found matching your filter.</p>
          <button
            onClick={() => {
              setCategory('All');
              setSearch('');
            }}
            className="mt-3 px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {campaigns.map((camp) => (
              <CampaignCard
                key={camp.id}
                campaign={camp}
                onViewDetails={onViewDetails}
              />
            ))}
          </div>

          {/* Accessible Pagination (Addresses Feedback directly!) */}
          <Pagination
            pagination={pagination}
            onPageChange={(newPage) => setPage(newPage)}
          />
        </>
      )}
    </section>
  );
}
