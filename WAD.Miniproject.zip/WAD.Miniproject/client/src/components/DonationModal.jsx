import React, { useState, useEffect } from 'react';
import { X, ShieldCheck, Sparkles, CreditCard, Smartphone, Building, Check, Loader2, ArrowRight } from 'lucide-react';
import confetti from 'canvas-confetti';
import { useDonor } from '../context/DonorContext';
import { formatIndianCurrency } from '../utils/currency';
import { calculateImpactEquivalency } from '../utils/impactCalculator';
import { submitDonation } from '../services/api';

export default function DonationModal() {
  const {
    donationModalOpen,
    setDonationModalOpen,
    activeCampaign,
    preselectedAmount,
    donorProfile,
    openReceiptModal,
    showToast,
    triggerDataRefresh
  } = useDonor();

  if (!donationModalOpen || !activeCampaign) return null;

  // Selected or custom amount
  const [amount, setAmount] = useState(preselectedAmount || 1500);
  const [customInput, setCustomInput] = useState(preselectedAmount ? String(preselectedAmount) : '1500');

  useEffect(() => {
    if (preselectedAmount) {
      setAmount(preselectedAmount);
      setCustomInput(String(preselectedAmount));
    } else if (activeCampaign?.tiers?.length > 0) {
      const popular = activeCampaign.tiers.find(t => t.is_popular) || activeCampaign.tiers[0];
      setAmount(popular.amount);
      setCustomInput(String(popular.amount));
    }
  }, [donationModalOpen, preselectedAmount, activeCampaign]);

  // Form Fields
  const [donorName, setDonorName] = useState(donorProfile.name);
  const [donorEmail, setDonorEmail] = useState(donorProfile.email);
  const [donorPhone, setDonorPhone] = useState(donorProfile.phone || '+91 98765 43210');
  const [donorPan, setDonorPan] = useState(donorProfile.pan || 'ABCDE1234F');
  const [donorAddress, setDonorAddress] = useState(donorProfile.address || '124 Indiranagar, Bengaluru, KA');
  const [paymentMethod, setPaymentMethod] = useState('UPI');

  // Processing state
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Live impact calculation
  const impact = calculateImpactEquivalency(amount, activeCampaign.unit_cost, activeCampaign.unit_name);

  // Handle Preset pill click
  function handlePresetClick(tierAmount) {
    setAmount(tierAmount);
    setCustomInput(String(tierAmount));
  }

  // Handle custom input change
  function handleCustomChange(val) {
    const clean = val.replace(/\D/g, '');
    setCustomInput(clean);
    const num = Number(clean);
    if (!isNaN(num) && num > 0) {
      setAmount(num);
    }
  }

  // PAN format validity check
  const isPanValid = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(donorPan.trim().toUpperCase());

  async function handleDonateSubmit(e) {
    e.preventDefault();
    setError(null);

    if (!isPanValid) {
      setError('Please enter a valid 10-character Indian PAN (e.g. ABCDE1234F) for 80G tax exemption.');
      return;
    }

    if (amount < 50) {
      setError('Minimum donation amount is ₹50.');
      return;
    }

    try {
      setLoading(true);

      const payload = {
        campaignId: activeCampaign.id,
        donorName: donorName.trim(),
        donorEmail: donorEmail.trim().toLowerCase(),
        donorPhone: donorPhone.trim(),
        donorPan: donorPan.trim().toUpperCase(),
        donorAddress: donorAddress.trim(),
        amount: Number(amount),
        paymentMethod
      };

      const result = await submitDonation(payload);

      // Trigger celebratory confetti animation
      confetti({
        particleCount: 120,
        spread: 70,
        origin: { y: 0.6 }
      });

      showToast(`Thank you! ₹${amount} donated to ${activeCampaign.title}.`);
      triggerDataRefresh();
      setDonationModalOpen(false);

      // Automatically launch instant 80G Receipt modal
      openReceiptModal(result.donation);
    } catch (err) {
      setError(err.message || 'Donation failed. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl border border-slate-200 my-8 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 bg-slate-50/80">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 flex items-center justify-center text-white font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">
                Verified 80G Tax-Deductible Contribution
              </span>
              <h3 className="text-base font-extrabold text-slate-900 line-clamp-1">
                {activeCampaign.title}
              </h3>
            </div>
          </div>

          <button
            onClick={() => setDonationModalOpen(false)}
            className="p-1.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-700 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleDonateSubmit} className="p-5 sm:p-6 space-y-5">
          {error && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold">
              {error}
            </div>
          )}

          {/* Dynamic Donation Tier Presets */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              Select Preset Impact Tier or Enter Custom Amount
            </label>

            {/* Dynamic Preset Tiers Pills */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
              {(activeCampaign.tiers && activeCampaign.tiers.length > 0
                ? activeCampaign.tiers
                : [
                    { amount: 500, label: '1 Unit', impact_desc: 'Base starter package' },
                    { amount: 1500, label: '3 Units', impact_desc: 'Popular impact tier' },
                    { amount: 3500, label: '7 Units', impact_desc: 'Community support' },
                    { amount: 10000, label: 'Full Sponsorship', impact_desc: 'High impact donor' }
                  ]
              ).map((tier) => (
                <button
                  key={tier.id || tier.amount}
                  type="button"
                  onClick={() => handlePresetClick(tier.amount)}
                  className={`p-2.5 rounded-xl border text-center transition ${
                    amount === tier.amount
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-2 ring-emerald-500 shadow-sm'
                      : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="font-extrabold text-sm">{formatIndianCurrency(tier.amount)}</div>
                  <div className="text-[10px] text-slate-500 font-medium truncate" title={tier.label}>
                    {tier.label}
                  </div>
                </button>
              ))}
            </div>

            {/* Custom Amount Input with Live Equivalency */}
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400 text-sm">
                ₹
              </span>
              <input
                type="text"
                value={customInput}
                onChange={(e) => handleCustomChange(e.target.value)}
                placeholder="Enter custom amount"
                className="w-full pl-8 pr-4 py-2.5 text-base font-bold text-slate-900 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                required
              />
            </div>
          </div>

          {/* Live Tangible Impact Equivalency Box */}
          <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-4">
            <div className="flex items-start gap-2.5">
              <Sparkles className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-800">
                  Live Tangible Ground Deliverable:
                </span>
                <div className="text-sm font-extrabold text-emerald-950 mt-0.5">
                  Your {formatIndianCurrency(amount)} delivers: <span className="underline decoration-emerald-500 decoration-2">{impact.deliverableText}</span>
                </div>
                <div className="text-[11px] text-emerald-700 mt-1">
                  Estimated Direct Lives Impacted: <strong>{impact.livesImpacted} Beneficiaries</strong>
                </div>

                {/* 85% / 10% / 5% Live Split */}
                <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t border-emerald-200/60 text-[10px]">
                  <div>
                    <span className="text-slate-500">Field Goods (85%):</span>
                    <div className="font-bold text-emerald-800">{formatIndianCurrency(impact.breakdown.fieldGoods)}</div>
                  </div>
                  <div>
                    <span className="text-slate-500">Logistics (10%):</span>
                    <div className="font-bold text-teal-800">{formatIndianCurrency(impact.breakdown.logistics)}</div>
                  </div>
                  <div>
                    <span className="text-slate-500">Admin (5%):</span>
                    <div className="font-bold text-slate-700">{formatIndianCurrency(impact.breakdown.admin)}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Donor Identification & 80G Compliance Fields */}
          <div className="space-y-3 pt-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Donor Details for Section 80G Tax Exemption
              </span>
              <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                Legal Tax Compliance
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Full Legal Name</label>
                <input
                  type="text"
                  value={donorName}
                  onChange={(e) => setDonorName(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Email (for 80G Receipt PDF)</label>
                <input
                  type="email"
                  value={donorEmail}
                  onChange={(e) => setDonorEmail(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1 flex items-center justify-between">
                  <span>Donor PAN Card Number</span>
                  <span className={`text-[10px] font-mono ${isPanValid ? 'text-emerald-600 font-bold' : 'text-slate-400'}`}>
                    {isPanValid ? '✓ Valid PAN Format' : '5 Letters, 4 Digits, 1 Letter'}
                  </span>
                </label>
                <input
                  type="text"
                  value={donorPan}
                  onChange={(e) => setDonorPan(e.target.value.toUpperCase())}
                  maxLength={10}
                  className="w-full text-xs font-mono uppercase px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">Mobile Number</label>
                <input
                  type="text"
                  value={donorPhone}
                  onChange={(e) => setDonorPhone(e.target.value)}
                  className="w-full text-xs px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>
            </div>
          </div>

          {/* Simulated Payment Methods */}
          <div className="space-y-2 pt-1">
            <label className="block text-xs font-bold text-slate-700">
              Select Demo Payment Method (Simulated Instant Sandbox Gateway)
            </label>

            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'UPI', label: 'Demo UPI', icon: Smartphone, desc: 'GPay, PhonePe, Paytm' },
                { id: 'NetBanking', label: 'Demo NetBanking', icon: Building, desc: 'HDFC, SBI, ICICI' },
                { id: 'Credit Card', label: 'Demo Card', icon: CreditCard, desc: 'Visa, MasterCard' }
              ].map((m) => {
                const Icon = m.icon;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setPaymentMethod(m.id)}
                    className={`p-2.5 rounded-xl border text-left transition ${
                      paymentMethod === m.id
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-2 ring-emerald-500'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold text-xs">
                      <Icon className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{m.label}</span>
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5 truncate">{m.desc}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-sm transition shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Processing Mock Checkout & Generating 80G Certificate...</span>
                </>
              ) : (
                <>
                  <span>Confirm Contribution of {formatIndianCurrency(amount)}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
            <p className="text-[10px] text-slate-400 text-center mt-2">
              Instant 80G tax receipt PDF will be generated immediately with verifiable QR seal upon payment.
            </p>
          </div>
        </form>
      </div>
    </div>
  );
}
