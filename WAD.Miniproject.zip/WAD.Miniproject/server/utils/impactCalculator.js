/**
 * Impact Equivalency Formulas
 * Calculates exact tangible units, lives impacted, and fund split
 */
function calculateImpactEquivalency(amount, unitCost, unitName) {
  const amt = Number(amount) || 0;
  const cost = Number(unitCost) || 500;
  const unitsCount = Math.floor(amt / cost);
  const remainingAmt = amt % cost;

  // Tangible deliverable statement
  let deliverableText = '';
  if (unitsCount > 0) {
    deliverableText = `${unitsCount} × ${unitName}`;
    if (remainingAmt > 0) {
      deliverableText += ` + ₹${remainingAmt} towards support logistics`;
    }
  } else {
    const fraction = ((amt / cost) * 100).toFixed(0);
    deliverableText = `${fraction}% of 1 ${unitName}`;
  }

  // Estimated lives directly impacted
  // Base rule: each primary unit impacts 1-2 primary beneficiaries + family indirect benefit
  const livesImpacted = Math.max(1, unitsCount);

  // Exact 85% - 10% - 5% fund allocation breakdown
  const fieldGoodsAllocation = Math.round(amt * 0.85);
  const logisticsAllocation = Math.round(amt * 0.10);
  const adminAllocation = amt - fieldGoodsAllocation - logisticsAllocation;

  return {
    amount: amt,
    unitCost: cost,
    unitName,
    unitsCount,
    deliverableText,
    livesImpacted,
    breakdown: {
      fieldGoods: fieldGoodsAllocation,
      fieldGoodsPct: 85,
      logistics: logisticsAllocation,
      logisticsPct: 10,
      admin: adminAllocation,
      adminPct: 5
    }
  };
}

module.exports = {
  calculateImpactEquivalency
};
