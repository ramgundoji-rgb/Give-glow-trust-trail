/**
 * Indian Currency Formatter (Lakhs & Crores format)
 */
function formatIndianCurrency(amount) {
  if (amount === undefined || amount === null || isNaN(amount)) return '₹0';
  const num = Math.round(Number(amount));
  return '₹' + formatIndianNumber(num);
}

function formatIndianNumber(num) {
  if (num === undefined || num === null || isNaN(num)) return '0';
  const n = Math.abs(Math.round(Number(num)));
  const str = n.toString();
  if (str.length <= 3) {
    return (num < 0 ? '-' : '') + str;
  }
  const lastThree = str.substring(str.length - 3);
  const otherNumbers = str.substring(0, str.length - 3);
  const formattedOthers = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  return (num < 0 ? '-' : '') + formattedOthers + ',' + lastThree;
}

module.exports = {
  formatIndianCurrency,
  formatIndianNumber
};
