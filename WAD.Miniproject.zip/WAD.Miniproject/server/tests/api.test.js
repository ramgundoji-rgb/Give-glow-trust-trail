const request = require('supertest');
const app = require('../app');
const { seedDatabase } = require('../db/seed');

beforeAll(async () => {
  await seedDatabase();
});

describe('GiveGlow TrustTrail REST API Endpoints', () => {
  describe('Health and System Status', () => {
    test('GET /api/health returns ok status', async () => {
      const res = await request(app).get('/api/health');
      expect(res.statusCode).toBe(200);
      expect(res.body.status).toBe('ok');
    });

    test('GET /api/campaigns/stats returns aggregated platform impact', async () => {
      const res = await request(app).get('/api/campaigns/stats');
      expect(res.statusCode).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.stats.totalCampaigns).toBeGreaterThanOrEqual(6);
      expect(res.body.stats.totalRaised).toBeGreaterThan(0);
      expect(res.body.stats.totalLivesImpacted).toBeGreaterThan(0);
    });
  });

  describe('Campaign Explorer & Pagination', () => {
    test('GET /api/campaigns returns 6 campaigns with pagination metadata', async () => {
      const res = await request(app).get('/api/campaigns?page=1&limit=6');
      expect(res.statusCode).toBe(200);
      expect(res.body.success).toBe(true);
      expect(Array.isArray(res.body.campaigns)).toBe(true);
      expect(res.body.campaigns.length).toBe(6);
      expect(res.body.pagination).toBeDefined();
      expect(res.body.pagination.total).toBe(6);
      expect(res.body.pagination.page).toBe(1);
    });

    test('GET /api/campaigns filters correctly by category', async () => {
      const res = await request(app).get('/api/campaigns?category=Child Education');
      expect(res.statusCode).toBe(200);
      expect(res.body.campaigns.every(c => c.category === 'Child Education')).toBe(true);
    });

    test('GET /api/campaigns/:id returns full campaign with tiers, ledger, and milestones', async () => {
      const res = await request(app).get('/api/campaigns/camp-stem-girls');
      expect(res.statusCode).toBe(200);
      expect(res.body.success).toBe(true);
      const camp = res.body.campaign;
      expect(camp.id).toBe('camp-stem-girls');
      expect(camp.title).toBe('Rural Girl STEM Education Drive');
      expect(camp.percentage).toBe(74); // As specified in problem brief demo
      expect(camp.tiers.length).toBeGreaterThanOrEqual(3);
      expect(camp.ledger.length).toBeGreaterThanOrEqual(3);
      expect(camp.milestones.length).toBeGreaterThanOrEqual(3);
    });

    test('GET /api/campaigns/:id returns 404 for unknown campaign', async () => {
      const res = await request(app).get('/api/campaigns/non-existent-campaign');
      expect(res.statusCode).toBe(404);
      expect(res.body.success).toBe(false);
    });
  });

  describe('Donation Processing, 80G Receipt & Balance Ledger Update', () => {
    test('POST /api/donations rejects invalid PAN or missing fields', async () => {
      const res = await request(app)
        .post('/api/donations')
        .send({
          campaignId: 'camp-stem-girls',
          donorName: 'Test Donor',
          donorEmail: 'test@example.com',
          donorPan: 'INVALID_PAN',
          amount: 1500,
          paymentMethod: 'UPI'
        });

      expect(res.statusCode).toBe(400);
      expect(res.body.success).toBe(false);
      expect(res.body.errors.some(e => e.includes('PAN'))).toBe(true);
    });

    test('POST /api/donations successfully processes Rs 1,500 donation for STEM Girls', async () => {
      const res = await request(app)
        .post('/api/donations')
        .send({
          campaignId: 'camp-stem-girls',
          donorName: 'Ananya Sharma',
          donorEmail: 'ananya.sharma@example.com',
          donorPhone: '+91 98450 12345',
          donorPan: 'ABCDE1234F',
          donorAddress: 'Flat 402, Green Glen Layout, Bengaluru',
          amount: 1500,
          paymentMethod: 'UPI'
        });

      expect(res.statusCode).toBe(201);
      expect(res.body.success).toBe(true);
      expect(res.body.donation).toBeDefined();
      expect(res.body.donation.amount).toBe(1500);
      expect(res.body.donation.amountInWords).toBe('One Thousand Five Hundred Rupees Only');
      expect(res.body.donation.receiptNo).toMatch(/^GG-80G-\d{4}-/);
      expect(res.body.donation.impactDetails.unitsCount).toBe(3);
      expect(res.body.donation.impactDetails.deliverableText).toBe('3 × Science Kit for 1 Girl');

      // Verify campaign was atomically updated
      expect(res.body.updatedCampaign.raised_amount).toBe(370000 + 1500);
      expect(res.body.updatedCampaign.donor_count).toBe(248 + 1);

      // Verify receipt lookup works
      const receiptRes = await request(app).get(`/api/receipts/${res.body.donation.receiptNo}`);
      expect(receiptRes.statusCode).toBe(200);
      expect(receiptRes.body.receipt.donor.name).toBe('Ananya Sharma');
      expect(receiptRes.body.receipt.donor.pan).toBe('ABCDE1234F');
      expect(receiptRes.body.receipt.legalClause).toContain('Section 80G');
    });
  });

  describe('Recurring Micro-Donation Pledge (Stretch Feature)', () => {
    test('POST /api/pledges creates automated monthly recurring pledge', async () => {
      const res = await request(app)
        .post('/api/pledges')
        .send({
          campaignId: 'camp-stem-girls',
          donorName: 'Rohan Mehra',
          donorEmail: 'rohan.mehra@example.com',
          donorPan: 'ABCDE1234F',
          monthlyAmount: 1000,
          paymentMethod: 'UPI AutoPay'
        });

      expect(res.statusCode).toBe(201);
      expect(res.body.success).toBe(true);
      expect(res.body.pledge.monthlyAmount).toBe(1000);
      expect(res.body.pledge.status).toBe('ACTIVE');

      const listRes = await request(app).get('/api/pledges?email=rohan.mehra@example.com');
      expect(listRes.statusCode).toBe(200);
      expect(listRes.body.pledges.length).toBeGreaterThanOrEqual(1);
    });
  });
});
