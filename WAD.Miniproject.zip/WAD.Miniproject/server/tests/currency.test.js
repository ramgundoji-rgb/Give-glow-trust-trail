const { formatIndianCurrency, formatIndianNumber } = require('../utils/currency');

describe('Indian Currency Formatting Utilities', () => {
  test('formats standard amounts in Indian numbering system', () => {
    expect(formatIndianCurrency(500)).toBe('₹500');
    expect(formatIndianCurrency(1500)).toBe('₹1,500');
    expect(formatIndianCurrency(25000)).toBe('₹25,000');
    expect(formatIndianCurrency(100000)).toBe('₹1,00,000'); // 1 Lakh
    expect(formatIndianCurrency(500000)).toBe('₹5,00,000'); // 5 Lakhs
    expect(formatIndianCurrency(10000000)).toBe('₹1,00,00,000'); // 1 Crore
  });

  test('formats numbers without currency symbol', () => {
    expect(formatIndianNumber(370000)).toBe('3,70,000');
    expect(formatIndianNumber(500000)).toBe('5,00,000');
    expect(formatIndianNumber(999)).toBe('999');
    expect(formatIndianNumber(1000)).toBe('1,000');
  });

  test('handles zero, null, undefined, and non-numeric values gracefully', () => {
    expect(formatIndianCurrency(0)).toBe('₹0');
    expect(formatIndianCurrency(null)).toBe('₹0');
    expect(formatIndianCurrency(undefined)).toBe('₹0');
    expect(formatIndianCurrency('invalid')).toBe('₹0');
  });

  test('handles decimal rounding properly', () => {
    expect(formatIndianCurrency(1500.75)).toBe('₹1,501');
    expect(formatIndianCurrency(1499.20)).toBe('₹1,499');
  });
});
