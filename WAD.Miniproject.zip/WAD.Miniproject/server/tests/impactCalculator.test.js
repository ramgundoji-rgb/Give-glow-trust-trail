const { calculateImpactEquivalency } = require('../utils/impactCalculator');

describe('Tangible Impact Equivalency Formulas', () => {
  test('calculates exact unit counts for STEM kits (unit cost 500)', () => {
    const result = calculateImpactEquivalency(1500, 500, 'Science Kit for 1 Girl');
    expect(result.unitsCount).toBe(3);
    expect(result.deliverableText).toBe('3 × Science Kit for 1 Girl');
    expect(result.livesImpacted).toBe(3);
  });

  test('calculates fractional unit for amounts smaller than unit cost', () => {
    const result = calculateImpactEquivalency(250, 500, 'Science Kit for 1 Girl');
    expect(result.unitsCount).toBe(0);
    expect(result.deliverableText).toBe('50% of 1 Science Kit for 1 Girl');
    expect(result.livesImpacted).toBe(1);
  });

  test('calculates unit count with remaining support logistics', () => {
    const result = calculateImpactEquivalency(1750, 500, 'Science Kit for 1 Girl');
    expect(result.unitsCount).toBe(3);
    expect(result.deliverableText).toContain('3 × Science Kit for 1 Girl');
    expect(result.deliverableText).toContain('₹250 towards support logistics');
  });

  test('verifies itemized fund breakdown matches 85% - 10% - 5%', () => {
    const result = calculateImpactEquivalency(10000, 500, 'Science Kit');
    expect(result.breakdown.fieldGoodsPct).toBe(85);
    expect(result.breakdown.logisticsPct).toBe(10);
    expect(result.breakdown.adminPct).toBe(5);

    expect(result.breakdown.fieldGoods).toBe(8500);
    expect(result.breakdown.logistics).toBe(1000);
    expect(result.breakdown.admin).toBe(500);
    expect(result.breakdown.fieldGoods + result.breakdown.logistics + result.breakdown.admin).toBe(10000);
  });
});
