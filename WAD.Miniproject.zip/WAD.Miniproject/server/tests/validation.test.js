const { isValidPAN, isValidEmail, sanitizeString } = require('../middleware/validation');

describe('Input Validation & Sanitization', () => {
  test('validates standard Indian PAN cards strictly', () => {
    expect(isValidPAN('ABCDE1234F')).toBe(true);
    expect(isValidPAN('abcde1234f')).toBe(true); // case-insensitive check
    expect(isValidPAN('XYZPA9999K')).toBe(true);

    // Invalid patterns
    expect(isValidPAN('ABCD12345F')).toBe(false); // 4 letters then 5 digits
    expect(isValidPAN('ABCDE12345')).toBe(false); // ends in digit
    expect(isValidPAN('12345ABCDE')).toBe(false);
    expect(isValidPAN('ABCDE123')).toBe(false); // too short
    expect(isValidPAN('')).toBe(false);
    expect(isValidPAN(null)).toBe(false);
  });

  test('validates donor email format', () => {
    expect(isValidEmail('donor@example.com')).toBe(true);
    expect(isValidEmail('praveen.kumar+charity@ngo.org.in')).toBe(true);
    expect(isValidEmail('invalid-email')).toBe(false);
    expect(isValidEmail('missing@domain')).toBe(false);
    expect(isValidEmail('')).toBe(false);
  });

  test('sanitizes strings and strips harmful HTML / XSS payloads', () => {
    expect(sanitizeString('<script>alert("xss")</script>John Doe')).toBe('John Doe');
    expect(sanitizeString('<b>Vigyan Pragati</b>')).toBe('Vigyan Pragati');
    expect(sanitizeString('   Clean String   ')).toBe('Clean String');
    expect(sanitizeString(123)).toBe('');
  });
});
