const { amountInWords } = require('../utils/numberToWords');

describe('Number to Indian Words Converter (for 80G Receipts)', () => {
  test('converts basic rupee amounts correctly', () => {
    expect(amountInWords(500)).toBe('Five Hundred Rupees Only');
    expect(amountInWords(1500)).toBe('One Thousand Five Hundred Rupees Only');
    expect(amountInWords(2500)).toBe('Two Thousand Five Hundred Rupees Only');
  });

  test('converts lakh amounts correctly', () => {
    expect(amountInWords(100000)).toBe('One Lakh Rupees Only');
    expect(amountInWords(370000)).toBe('Three Lakh Seventy Thousand Rupees Only');
    expect(amountInWords(500000)).toBe('Five Lakh Rupees Only');
  });

  test('converts crore amounts correctly', () => {
    expect(amountInWords(10000000)).toBe('One Crore Rupees Only');
    expect(amountInWords(12500000)).toBe('One Crore Twenty Five Lakh Rupees Only');
  });

  test('handles zero and invalid inputs safely', () => {
    expect(amountInWords(0)).toBe('Zero Rupees Only');
    expect(amountInWords(-100)).toBe('Zero Rupees Only');
    expect(amountInWords('abc')).toBe('Zero Rupees Only');
  });
});
