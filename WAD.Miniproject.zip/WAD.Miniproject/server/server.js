const app = require('./app');
const { initSchema } = require('./db/database');

const PORT = process.env.PORT || 5001;

async function start() {
  try {
    await initSchema();
    app.listen(PORT, () => {
      console.log(`🚀 GiveGlow TrustTrail Backend running on http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
}

start();
