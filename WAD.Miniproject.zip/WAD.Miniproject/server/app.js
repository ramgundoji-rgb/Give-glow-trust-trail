const express = require('express');
const cors = require('cors');
const { errorHandler } = require('./middleware/errorHandler');

const campaignRoutes = require('./routes/campaigns');
const donationRoutes = require('./routes/donations');
const receiptRoutes = require('./routes/receipts');
const pledgeRoutes = require('./routes/pledges');

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Mount Routes
app.use('/api/campaigns', campaignRoutes);
app.use('/api/donations', donationRoutes);
app.use('/api/receipts', receiptRoutes);
app.use('/api/pledges', pledgeRoutes);

// Catch-all 404 for API routes
app.use('/api/*', (req, res) => {
  res.status(404).json({
    success: false,
    message: `API route '${req.originalUrl}' not found.`
  });
});

// Error handling middleware
app.use(errorHandler);

module.exports = app;
