const { db, query, initSchema } = require('./database');

async function seedDatabase() {
  await initSchema();

  // Clear existing data for fresh idempotent seeding
  await query.run('DELETE FROM fund_ledger');
  await query.run('DELETE FROM donation_tiers');
  await query.run('DELETE FROM milestones');
  await query.run('DELETE FROM donations');
  await query.run('DELETE FROM pledges');
  await query.run('DELETE FROM campaigns');

  console.log('Cleared existing tables. Seeding authentic campaigns...');

  const campaigns = [
    {
      id: 'camp-stem-girls',
      title: 'Rural Girl STEM Education Drive',
      category: 'Child Education',
      ngo_name: 'Vigyan Pragati Foundation',
      ngo_reg_no: 'U80903KA2018NPL112345',
      ngo_80g_reg: 'AABTV4589PF20214',
      description: 'Equipping adolescent girls in underserved rural schools with hands-on practical physics, robotics, and biology laboratory kits.',
      story: 'In rural Karnataka districts like Raichur and Yadgir, girls drop out of science streams simply because schools lack laboratories. Vigyan Pragati builds mobile STEM science stations and delivers personal laboratory boxes containing circuits, microscopes, and chemical reaction sets to every enrolled student.',
      goal_amount: 500000,
      raised_amount: 370000, // Exactly 74% as per Problem Brief
      donor_count: 248,
      deadline: '2026-12-31',
      image_url: 'https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&w=1000&q=80',
      location: 'Raichur & Yadgir, Karnataka',
      beneficiary_type: 'Underprivileged High School Girls (Ages 11-16)',
      field_goods_pct: 85,
      logistics_pct: 10,
      admin_pct: 5,
      unit_name: 'Science Kit for 1 Girl',
      unit_cost: 500
    },
    {
      id: 'camp-slum-meals',
      title: 'Mid-Day Nutritious Meals for Slum Children',
      category: 'Child Nutrition',
      ngo_name: 'Annapurna Feeding Hope Trust',
      ngo_reg_no: 'IV-190200845/DL',
      ngo_80g_reg: 'AACTA9823NF20201',
      description: 'Providing hot protein-rich mid-day lunches to eradicate classroom hunger and improve school retention in urban slum settlements.',
      story: 'Malnutrition affects over 42% of children in urban informal settlements. Our community kitchens prepare wholesome khichdi, lentils, greens, and fortified milk packets distributed daily before lessons begin.',
      goal_amount: 350000,
      raised_amount: 280000,
      donor_count: 412,
      deadline: '2026-11-30',
      image_url: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1000&q=80',
      location: 'Dharavi & Govandi, Mumbai',
      beneficiary_type: 'Slum School Pupils (Ages 5-14)',
      field_goods_pct: 85,
      logistics_pct: 10,
      admin_pct: 5,
      unit_name: 'Monthly Hot Meal Kit',
      unit_cost: 500
    },
    {
      id: 'camp-flood-relief',
      title: 'Assam & Bihar Flood Relief Care Packages',
      category: 'Disaster Relief',
      ngo_name: 'Jan Seva Disaster Response Corps',
      ngo_reg_no: 'NDRF/NGO-AS/2019/88',
      ngo_80g_reg: 'AABTJ5512RF20199',
      description: 'Rapid deployment of life-saving potable water tablets, dry grain rations, waterproof tarpaulins, and halogen torches to marooned flood victims.',
      story: 'Brahmaputra overflow floods submerge hundreds of riverine villages annually. Our inflatable boat fleets deliver emergency care packages directly to isolated rooftops and flood embankment shelters within 12 hours of distress beacons.',
      goal_amount: 800000,
      raised_amount: 520000,
      donor_count: 390,
      deadline: '2026-10-15',
      image_url: 'https://images.unsplash.com/photo-1547082299-de196ea013d6?auto=format&fit=crop&w=1000&q=80',
      location: 'Dhemaji & Barpeta, Assam',
      beneficiary_type: 'Marooned Riverine Families',
      field_goods_pct: 85,
      logistics_pct: 10,
      admin_pct: 5,
      unit_name: 'Family Emergency Ration & Water Kit',
      unit_cost: 1000
    },
    {
      id: 'camp-stray-welfare',
      title: 'Stray Animal Rabies Vaccination & Rescue Care',
      category: 'Animal Welfare',
      ngo_name: 'Voice of Stray Pawssion',
      ngo_reg_no: 'AWBI/DL/2020/00492',
      ngo_80g_reg: 'AAAVP3341PF20228',
      description: 'City-wide anti-rabies immunizations, reflective safety collars, spot trauma surgeries, and sterilizations for stray dogs and cats.',
      story: 'Street animals in urban corridors suffer severe vehicular collisions and diseases. We run mobile ambulance triage units, vaccinate entire street packs, fit glowing collars, and rehabilitate injured indie pups.',
      goal_amount: 250000,
      raised_amount: 165000,
      donor_count: 184,
      deadline: '2027-01-31',
      image_url: 'https://images.unsplash.com/photo-1548767797-d8c844163c4c?auto=format&fit=crop&w=1000&q=80',
      location: 'Delhi NCR (South & West zones)',
      beneficiary_type: 'Community Dogs, Cats & Rescued Equines',
      field_goods_pct: 85,
      logistics_pct: 10,
      admin_pct: 5,
      unit_name: 'Vaccination, Deworming & Collar Kit',
      unit_cost: 250
    },
    {
      id: 'camp-rural-health',
      title: 'Mobile Healthcare Clinic for Remote Tribal Belts',
      category: 'Rural Healthcare',
      ngo_name: 'Arogya Vahini Foundation',
      ngo_reg_no: 'MH/PUN/8842/2017',
      ngo_80g_reg: 'AABTA6678EF20212',
      description: 'State-of-the-art all-terrain diagnostic ambulance delivering maternal prenatal checks, hemoglobin screening, and essential medicines to remote forest hamlets.',
      story: 'Tribal families in the Satpura range often walk over 25 kilometers to reach the nearest primary healthcare center. Our mobile medical team visits 18 isolated padas each week, providing on-the-spot pathology testing and free generic treatments.',
      goal_amount: 600000,
      raised_amount: 450000,
      donor_count: 310,
      deadline: '2026-12-15',
      image_url: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=1000&q=80',
      location: 'Nandurbar & Melghat, Maharashtra',
      beneficiary_type: 'Forest-dwelling Tribal Mothers & Elders',
      field_goods_pct: 85,
      logistics_pct: 10,
      admin_pct: 5,
      unit_name: 'Tribal Diagnostic & Medication Pack',
      unit_cost: 600
    },
    {
      id: 'camp-clean-water',
      title: 'Solar Clean Drinking Water Filtration Plants',
      category: 'Clean Water',
      ngo_name: 'Jal Jeevan Suraksha Mission',
      ngo_reg_no: 'RJ/JPR/1109/2019',
      ngo_80g_reg: 'AACJJ7781DF20205',
      description: 'Installing community solar-powered reverse osmosis and multi-stage ultraviolet filtration plants in fluoride-affected arid desert villages.',
      story: 'Groundwater in the Thar desert fringes has high TDS and fluoride toxicity causing dental fluorosis in children. We build self-sustaining solar water kiosks delivering 5,000 liters of pure mineralized drinking water every day.',
      goal_amount: 450000,
      raised_amount: 315000,
      donor_count: 220,
      deadline: '2027-02-28',
      image_url: 'https://images.unsplash.com/photo-1541888946425-d0fbb18086f6?auto=format&fit=crop&w=1000&q=80',
      location: 'Barmer & Pokhran, Rajasthan',
      beneficiary_type: 'Arid Village Households & Desert Schools',
      field_goods_pct: 85,
      logistics_pct: 10,
      admin_pct: 5,
      unit_name: 'Solar Filtration Shares (1 Family for 1 Year)',
      unit_cost: 1500
    }
  ];

  for (const c of campaigns) {
    await query.run(
      `INSERT INTO campaigns (id, title, category, ngo_name, ngo_reg_no, ngo_80g_reg, description, story, goal_amount, raised_amount, donor_count, deadline, image_url, location, beneficiary_type, field_goods_pct, logistics_pct, admin_pct, unit_name, unit_cost)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        c.id, c.title, c.category, c.ngo_name, c.ngo_reg_no, c.ngo_80g_reg,
        c.description, c.story, c.goal_amount, c.raised_amount, c.donor_count,
        c.deadline, c.image_url, c.location, c.beneficiary_type,
        c.field_goods_pct, c.logistics_pct, c.admin_pct, c.unit_name, c.unit_cost
      ]
    );
  }

  // Donation tiers presets
  const tiers = [
    // STEM Girls tiers
    { campaign_id: 'camp-stem-girls', amount: 500, label: '1 Science Kit', impact_desc: 'Provides 1 girl with individual optics & circuit lab box', is_popular: 0 },
    { campaign_id: 'camp-stem-girls', amount: 1500, label: 'Sponsors Science Kits for 3 Girls', impact_desc: 'Equips 3 young girls with full semester STEM kits', is_popular: 1 },
    { campaign_id: 'camp-stem-girls', amount: 3500, label: 'Lab Bench Sponsor (7 Girls)', impact_desc: 'Sponsors an entire classroom STEM workgroup', is_popular: 0 },
    { campaign_id: 'camp-stem-girls', amount: 10000, label: 'School Digital Microscope Station', impact_desc: 'Installs 1 high-resolution digital microscope in school lab', is_popular: 0 },

    // Slum Meals tiers
    { campaign_id: 'camp-slum-meals', amount: 500, label: '1 Month Mid-Day Meals', impact_desc: 'Feeds 1 child hot nutritious lunch for 30 school days', is_popular: 0 },
    { campaign_id: 'camp-slum-meals', amount: 1500, label: 'Quarterly Nutrition Sponsor', impact_desc: 'Guarantees 3 months of protein meals for 1 student', is_popular: 1 },
    { campaign_id: 'camp-slum-meals', amount: 5000, label: 'Classroom Daily Feast', impact_desc: 'Feeds 10 slum children full meals for an entire month', is_popular: 0 },

    // Flood Relief tiers
    { campaign_id: 'camp-flood-relief', amount: 1000, label: '1 Family Relief Pack', impact_desc: 'Dry rations, halogen torch & chlorine water purification tablets', is_popular: 0 },
    { campaign_id: 'camp-flood-relief', amount: 3000, label: '3 Families Emergency Shield', impact_desc: 'Tarpaulin shelter kits and rations for 3 families', is_popular: 1 },
    { campaign_id: 'camp-flood-relief', amount: 10000, label: 'Community Boat Rescue Mission', impact_desc: 'Funds fuel, rescue rafts and medical trauma kits', is_popular: 0 },

    // Stray Welfare tiers
    { campaign_id: 'camp-stray-welfare', amount: 250, label: '1 Rabies Vaccine & Collar', impact_desc: 'Vaccinates and fits neon safety collar on 1 street dog', is_popular: 0 },
    { campaign_id: 'camp-stray-welfare', amount: 1000, label: 'Pack Protection (4 Dogs)', impact_desc: 'Vaccinates, deworms and collars a full street pack', is_popular: 1 },
    { campaign_id: 'camp-stray-welfare', amount: 2500, label: 'Emergency Surgery Triage', impact_desc: 'Covers suture surgery and pain relief for injured stray', is_popular: 0 },

    // Rural Healthcare tiers
    { campaign_id: 'camp-rural-health', amount: 600, label: '1 Family Medical Kit', impact_desc: 'Vitamins, fever meds, bandages and rapid blood tests', is_popular: 0 },
    { campaign_id: 'camp-rural-health', amount: 1800, label: '3 Families Health Checkup', impact_desc: 'Doctor consultation, ECG and basic antibiotics for 3 families', is_popular: 1 },
    { campaign_id: 'camp-rural-health', amount: 6000, label: 'Hamlet Day-Clinic Sponsor', impact_desc: 'Full mobile medical van day-visit to 1 remote settlement', is_popular: 0 },

    // Clean Water tiers
    { campaign_id: 'camp-clean-water', amount: 750, label: '6-Month Clean Water Share', impact_desc: 'Supplies 1 desert household with 5,000L purified water', is_popular: 0 },
    { campaign_id: 'camp-clean-water', amount: 1500, label: '1 Year Mineralized Water Supply', impact_desc: 'Pure solar RO water for 1 family for 365 days', is_popular: 1 },
    { campaign_id: 'camp-clean-water', amount: 7500, label: 'School UV Water Cooler Unit', impact_desc: 'Installs high-capacity stainless drinking station for students', is_popular: 0 }
  ];

  for (const t of tiers) {
    await query.run(
      `INSERT INTO donation_tiers (campaign_id, amount, label, impact_desc, is_popular)
       VALUES (?, ?, ?, ?, ?)`,
      [t.campaign_id, t.amount, t.label, t.impact_desc, t.is_popular]
    );
  }

  // Itemized Fund Utilization Ledger
  const ledgerEntries = [
    // camp-stem-girls
    {
      campaign_id: 'camp-stem-girls',
      category: 'Field Goods',
      item_name: 'STEM Hands-On Physics & Electronics Kits (740 Units)',
      allocated_amount: 370000,
      spent_amount: 314500,
      vendor_recipient: 'EduTech Kits Manufacturing Pvt Ltd, Bengaluru',
      invoice_ref: 'INV-ETK-2026-0881',
      verification_hash: '8f3a9e4b7c1d2e5a6b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a',
      audit_date: '2026-05-14'
    },
    {
      campaign_id: 'camp-stem-girls',
      category: 'Logistics',
      item_name: 'Temperature-Controlled Dispatch & Last-Mile School Delivery',
      allocated_amount: 50000,
      spent_amount: 37000,
      vendor_recipient: 'Karnataka Rural Cargo Logistics',
      invoice_ref: 'INV-KRC-2026-4412',
      verification_hash: '1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b',
      audit_date: '2026-05-18'
    },
    {
      campaign_id: 'camp-stem-girls',
      category: 'Administration',
      item_name: 'Instructor Teacher Workshop & 80G Compliance Auditing',
      allocated_amount: 25000,
      spent_amount: 18500,
      vendor_recipient: 'Vigyan Pragati Monitoring Cell & Audit Partner S.R. Associates',
      invoice_ref: 'INV-AUD-2026-109',
      verification_hash: '9e8d7c6b5a4f3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e4d3c2b1a0f9e8d',
      audit_date: '2026-05-20'
    },

    // camp-slum-meals
    {
      campaign_id: 'camp-slum-meals',
      category: 'Field Goods',
      item_name: 'Organic Lentils, Fortified Flour, Rice & Seasonal Veggies',
      allocated_amount: 297500,
      spent_amount: 238000,
      vendor_recipient: 'Maha-Agro Farmers Producer Co-op',
      invoice_ref: 'INV-AGR-2026-9901',
      verification_hash: 'c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2',
      audit_date: '2026-06-02'
    },
    {
      campaign_id: 'camp-slum-meals',
      category: 'Logistics',
      item_name: 'Insulated Hot-Van Delivery to 8 Slum Clusters',
      allocated_amount: 35000,
      spent_amount: 28000,
      vendor_recipient: 'SpeedFleet Cold-Chain Delivery',
      invoice_ref: 'INV-SFC-2026-1234',
      verification_hash: 'e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6',
      audit_date: '2026-06-05'
    },
    {
      campaign_id: 'camp-slum-meals',
      category: 'Administration',
      item_name: 'FSSAI Hygiene Certification & Kitchen Oversight',
      allocated_amount: 17500,
      spent_amount: 14000,
      vendor_recipient: 'FoodSafe India QA Labs',
      invoice_ref: 'INV-FSS-2026-302',
      verification_hash: '7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b',
      audit_date: '2026-06-10'
    },

    // camp-flood-relief
    {
      campaign_id: 'camp-flood-relief',
      category: 'Field Goods',
      item_name: 'Chlorine Water Tablets, Halogen Lamps & Dry Ration Baskets',
      allocated_amount: 680000,
      spent_amount: 442000,
      vendor_recipient: 'Assam Emergency Provisions Agency',
      invoice_ref: 'INV-EPA-2026-778',
      verification_hash: '3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a',
      audit_date: '2026-07-01'
    },
    {
      campaign_id: 'camp-flood-relief',
      category: 'Logistics',
      item_name: 'Inflatable Raft Fuel, Drone Reconnaissance & Air Drops',
      allocated_amount: 80000,
      spent_amount: 52000,
      vendor_recipient: 'Brahmaputra Rapid Marine Transport',
      invoice_ref: 'INV-BRM-2026-440',
      verification_hash: '5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e',
      audit_date: '2026-07-03'
    },
    {
      campaign_id: 'camp-flood-relief',
      category: 'Administration',
      item_name: 'Field Volunteer Insurance & Verification Tracking',
      allocated_amount: 40000,
      spent_amount: 26000,
      vendor_recipient: 'ReliefCorps HQ Administrative Office',
      invoice_ref: 'INV-RCH-2026-911',
      verification_hash: '2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f',
      audit_date: '2026-07-05'
    }
  ];

  for (const l of ledgerEntries) {
    await query.run(
      `INSERT INTO fund_ledger (campaign_id, category, item_name, allocated_amount, spent_amount, vendor_recipient, invoice_ref, verification_hash, audit_date)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [l.campaign_id, l.category, l.item_name, l.allocated_amount, l.spent_amount, l.vendor_recipient, l.invoice_ref, l.verification_hash, l.audit_date]
    );
  }

  // Photographic Impact Milestone Feed
  const milestones = [
    {
      campaign_id: 'camp-stem-girls',
      title: 'Batch 1 STEM Kits Handover at Yadgir Girls High School',
      description: 'Distributed 240 physics and optics laboratory sets to 8th and 9th standard girls. The students assembled their first series circuits and concave mirror projections in their brand new science club session.',
      date: '2026-04-12',
      recipients_count: 240,
      image_url: 'https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&w=1000&q=80',
      video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      location: 'Government Girls High School, Yadgir',
      gps_coords: '16.7644° N, 77.1378° E',
      verifier_name: 'KPMG India Independent Audit Partner',
      verification_badge: 'VERIFIED_ON_GROUND'
    },
    {
      campaign_id: 'camp-stem-girls',
      title: 'Raichur Rural Block Chemistry Experiments Fair',
      description: 'Over 310 young girls conducted titration and plant pigment chromatography using their donated test-tube stations. 12 girls qualified for the state-level INSPIRE science talent awards.',
      date: '2026-05-18',
      recipients_count: 310,
      image_url: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=1000&q=80',
      video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      location: 'Raichur Science Hub, Karnataka',
      gps_coords: '16.2076° N, 77.3463° E',
      verifier_name: 'District Education Officer (DEO) Raichur',
      verification_badge: 'GOVT_OFFICIAL_VERIFIED'
    },
    {
      campaign_id: 'camp-stem-girls',
      title: 'Solar Robotics Mini-Challenge Workshop',
      description: 'Girls built miniature solar rovers and light-tracking fans with electronic components provided by GiveGlow donors. Attendance jumped by 28% following the lab installation.',
      date: '2026-06-25',
      recipients_count: 190,
      image_url: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1000&q=80',
      video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
      location: 'Sindhanur Secondary School, Karnataka',
      gps_coords: '15.7766° N, 76.7588° E',
      verifier_name: 'Panchayat Development Board Attested',
      verification_badge: 'COMMUNITY_ATTESTED'
    },

    // camp-slum-meals
    {
      campaign_id: 'camp-slum-meals',
      title: 'Dharavi Slum Community Kitchen 10,000 Meals Milestone',
      description: 'Crossed 10,000 freshly cooked warm meals distributed to primary school students across 4 wards of Dharavi. Zero school dropouts recorded in beneficiary classrooms.',
      date: '2026-05-01',
      recipients_count: 850,
      image_url: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=1000&q=80',
      video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
      location: 'Dharavi Sector 5 Kitchen, Mumbai',
      gps_coords: '19.0433° N, 72.8550° E',
      verifier_name: 'Brihanmumbai Municipal Corporation Health Inspector',
      verification_badge: 'GOVT_OFFICIAL_VERIFIED'
    },
    {
      campaign_id: 'camp-slum-meals',
      title: 'Govandi Monsoon Nutrition Shield Drive',
      description: 'Distributed immune-boosting protein drinks, multivitamins, and boiled egg / sprouts meals to ward off seasonal waterborne illnesses during heavy monsoons.',
      date: '2026-06-14',
      recipients_count: 620,
      image_url: 'https://images.unsplash.com/photo-1594708767771-a7502209ff51?auto=format&fit=crop&w=1000&q=80',
      video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
      location: 'Govandi Shivaji Nagar Community Center',
      gps_coords: '19.0620° N, 72.9234° E',
      verifier_name: 'Charity Navigator India Field Auditor',
      verification_badge: 'VERIFIED_ON_GROUND'
    },

    // camp-flood-relief
    {
      campaign_id: 'camp-flood-relief',
      title: 'Emergency Boat Delivery in Dhemaji Lowlands',
      description: 'Delivered 500 waterproof rations, 10,000 water purifying halazone tablets, and 250 heavy-duty plastic tarpaulins to marooned families across 6 river island hamlets.',
      date: '2026-06-30',
      recipients_count: 500,
      image_url: 'https://images.unsplash.com/photo-1547082299-de196ea013d6?auto=format&fit=crop&w=1000&q=80',
      video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
      location: 'Dhemaji Sub-division, Assam',
      gps_coords: '27.4812° N, 94.5776° E',
      verifier_name: 'State Disaster Management Authority (ASDMA)',
      verification_badge: 'GOVT_OFFICIAL_VERIFIED'
    },

    // camp-stray-welfare
    {
      campaign_id: 'camp-stray-welfare',
      title: 'Mass Anti-Rabies & Neon Collar Drive in Dwarka',
      description: 'Trained veterinary teams successfully vaccinated 320 community dogs and fitted high-visibility neon reflective collars to prevent nighttime highway accidents.',
      date: '2026-05-22',
      recipients_count: 320,
      image_url: 'https://images.unsplash.com/photo-1548767797-d8c844163c4c?auto=format&fit=crop&w=1000&q=80',
      video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
      location: 'Dwarka Sectors 11-19, New Delhi',
      gps_coords: '28.5823° N, 77.0500° E',
      verifier_name: 'Animal Welfare Board of India (AWBI) Inspector',
      verification_badge: 'VERIFIED_ON_GROUND'
    },

    // camp-rural-health
    {
      campaign_id: 'camp-rural-health',
      title: 'Melghat Tribal Diagnostic Outreach Clinic',
      description: 'Mobile medical clinic conducted anemia screenings for 410 expectant mothers, supplied calcium iron supplements, and safely transferred 4 high-risk mothers to district hospital.',
      date: '2026-06-10',
      recipients_count: 410,
      image_url: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=1000&q=80',
      video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4',
      location: 'Melghat Tiger Reserve Peripheral Padas, Maharashtra',
      gps_coords: '21.4333° N, 77.1667° E',
      verifier_name: 'District Medical Officer (DMO) Amravati',
      verification_badge: 'GOVT_OFFICIAL_VERIFIED'
    },

    // camp-clean-water
    {
      campaign_id: 'camp-clean-water',
      title: 'Pokhran Village Solar RO Kiosk Commissioning',
      description: 'Installed 5,000 LPD solar-powered water de-fluoridation plant. Tested TDS dropped from hazardous 1,840 ppm down to pure 120 ppm, serving 750 villagers daily.',
      date: '2026-05-19',
      recipients_count: 750,
      image_url: 'https://images.unsplash.com/photo-1541888946425-d0fbb18086f6?auto=format&fit=crop&w=1000&q=80',
      video_url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
      location: 'Village Bhadariya, Pokhran, Rajasthan',
      gps_coords: '26.9189° N, 71.9168° E',
      verifier_name: 'Public Health Engineering Department (PHED) Rajasthan',
      verification_badge: 'GOVT_OFFICIAL_VERIFIED'
    }
  ];

  for (const m of milestones) {
    await query.run(
      `INSERT INTO milestones (campaign_id, title, description, date, recipients_count, image_url, video_url, location, gps_coords, verifier_name, verification_badge)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [m.campaign_id, m.title, m.description, m.date, m.recipients_count, m.image_url, m.video_url, m.location, m.gps_coords, m.verifier_name, m.verification_badge]
    );
  }

  // Pre-seed some authentic sample donations to display in the Portfolio / Dashboard
  const initialDonations = [
    {
      id: 'DON-2026-901',
      campaign_id: 'camp-stem-girls',
      donor_name: 'Praveen Kumar',
      donor_email: 'praveen.kumar@example.com',
      donor_phone: '+91 98765 43210',
      donor_pan: 'ABCDE1234F',
      donor_address: '124 Indiranagar, Bengaluru, KA',
      amount: 1500,
      impact_summary: 'Sponsors Science Kits for 3 Girls (3 × Science Kit for 1 Girl)',
      payment_method: 'UPI',
      payment_status: 'SUCCESS',
      receipt_no: 'GG-80G-2026-00412',
      tax_exemption_ref: '80G/2026/VPF/00412',
      is_anonymous: 0,
      created_at: '2026-05-10 14:32:00'
    },
    {
      id: 'DON-2026-874',
      campaign_id: 'camp-slum-meals',
      donor_name: 'Praveen Kumar',
      donor_email: 'praveen.kumar@example.com',
      donor_phone: '+91 98765 43210',
      donor_pan: 'ABCDE1234F',
      donor_address: '124 Indiranagar, Bengaluru, KA',
      amount: 2500,
      impact_summary: '5 × Monthly Hot Meal Kit for Slum Children',
      payment_method: 'NetBanking',
      payment_status: 'SUCCESS',
      receipt_no: 'GG-80G-2026-00388',
      tax_exemption_ref: '80G/2026/AFH/00388',
      is_anonymous: 0,
      created_at: '2026-04-20 11:15:00'
    },
    {
      id: 'DON-2026-802',
      campaign_id: 'camp-flood-relief',
      donor_name: 'Praveen Kumar',
      donor_email: 'praveen.kumar@example.com',
      donor_phone: '+91 98765 43210',
      donor_pan: 'ABCDE1234F',
      donor_address: '124 Indiranagar, Bengaluru, KA',
      amount: 2000,
      impact_summary: '2 × Family Emergency Ration & Water Kit',
      payment_method: 'Credit Card',
      payment_status: 'SUCCESS',
      receipt_no: 'GG-80G-2026-00310',
      tax_exemption_ref: '80G/2026/JSD/00310',
      is_anonymous: 0,
      created_at: '2026-03-12 18:45:00'
    }
  ];

  for (const d of initialDonations) {
    await query.run(
      `INSERT INTO donations (id, campaign_id, donor_name, donor_email, donor_phone, donor_pan, donor_address, amount, impact_summary, payment_method, payment_status, receipt_no, tax_exemption_ref, is_anonymous, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        d.id, d.campaign_id, d.donor_name, d.donor_email, d.donor_phone, d.donor_pan,
        d.donor_address, d.amount, d.impact_summary, d.payment_method, d.payment_status,
        d.receipt_no, d.tax_exemption_ref, d.is_anonymous, d.created_at
      ]
    );
  }

  // Pre-seed an active recurring pledge for the stretch feature
  await query.run(
    `INSERT INTO pledges (id, campaign_id, donor_name, donor_email, donor_pan, monthly_amount, frequency, start_date, payment_method, status, next_charge_date)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      'PLG-2026-01',
      'camp-stem-girls',
      'Praveen Kumar',
      'praveen.kumar@example.com',
      'ABCDE1234F',
      1000,
      'MONTHLY',
      '2026-05-01',
      'UPI AutoPay',
      'ACTIVE',
      '2026-06-01'
    ]
  );

  console.log('✅ Seed completed successfully! 6 campaigns, tiers, ledgers, milestones, donations and pledges ready.');
}

if (require.main === module) {
  seedDatabase().then(() => {
    process.exit(0);
  }).catch(err => {
    console.error('Seed error:', err);
    process.exit(1);
  });
}

module.exports = { seedDatabase };
