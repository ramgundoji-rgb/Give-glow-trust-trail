const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

const dbPath = path.resolve(__dirname, 'giveglow.db');

const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Failed to open SQLite database:', err.message);
  } else {
    // console.log('Connected to SQLite database at:', dbPath);
  }
});

// Promisified database helpers
const query = {
  all(sql, params = []) {
    return new Promise((resolve, reject) => {
      db.all(sql, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });
  },
  get(sql, params = []) {
    return new Promise((resolve, reject) => {
      db.get(sql, params, (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });
  },
  run(sql, params = []) {
    return new Promise((resolve, reject) => {
      db.run(sql, params, function (err) {
        if (err) reject(err);
        else resolve({ lastID: this.lastID, changes: this.changes });
      });
    });
  },
  exec(sql) {
    return new Promise((resolve, reject) => {
      db.exec(sql, (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  }
};

async function initSchema() {
  const schema = `
    CREATE TABLE IF NOT EXISTS campaigns (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      category TEXT NOT NULL,
      ngo_name TEXT NOT NULL,
      ngo_reg_no TEXT NOT NULL,
      ngo_80g_reg TEXT NOT NULL,
      description TEXT NOT NULL,
      story TEXT,
      goal_amount INTEGER NOT NULL,
      raised_amount INTEGER NOT NULL DEFAULT 0,
      donor_count INTEGER NOT NULL DEFAULT 0,
      deadline TEXT NOT NULL,
      image_url TEXT,
      location TEXT NOT NULL,
      beneficiary_type TEXT,
      field_goods_pct INTEGER DEFAULT 85,
      logistics_pct INTEGER DEFAULT 10,
      admin_pct INTEGER DEFAULT 5,
      unit_name TEXT NOT NULL,
      unit_cost INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS donation_tiers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      campaign_id TEXT NOT NULL,
      amount INTEGER NOT NULL,
      label TEXT NOT NULL,
      impact_desc TEXT NOT NULL,
      is_popular INTEGER DEFAULT 0,
      FOREIGN KEY (campaign_id) REFERENCES campaigns (id)
    );

    CREATE TABLE IF NOT EXISTS fund_ledger (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      campaign_id TEXT NOT NULL,
      category TEXT NOT NULL,
      item_name TEXT NOT NULL,
      allocated_amount INTEGER NOT NULL,
      spent_amount INTEGER NOT NULL,
      vendor_recipient TEXT NOT NULL,
      invoice_ref TEXT NOT NULL,
      verification_hash TEXT NOT NULL,
      audit_date TEXT NOT NULL,
      FOREIGN KEY (campaign_id) REFERENCES campaigns (id)
    );

    CREATE TABLE IF NOT EXISTS milestones (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      campaign_id TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      date TEXT NOT NULL,
      recipients_count INTEGER NOT NULL,
      image_url TEXT NOT NULL,
      video_url TEXT,
      location TEXT NOT NULL,
      gps_coords TEXT,
      verifier_name TEXT NOT NULL,
      verification_badge TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (campaign_id) REFERENCES campaigns (id)
    );

    CREATE TABLE IF NOT EXISTS donations (
      id TEXT PRIMARY KEY,
      campaign_id TEXT NOT NULL,
      donor_name TEXT NOT NULL,
      donor_email TEXT NOT NULL,
      donor_phone TEXT,
      donor_pan TEXT NOT NULL,
      donor_address TEXT,
      amount INTEGER NOT NULL,
      impact_summary TEXT,
      payment_method TEXT NOT NULL,
      payment_status TEXT NOT NULL DEFAULT 'SUCCESS',
      receipt_no TEXT UNIQUE NOT NULL,
      tax_exemption_ref TEXT NOT NULL,
      is_anonymous INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (campaign_id) REFERENCES campaigns (id)
    );

    CREATE TABLE IF NOT EXISTS pledges (
      id TEXT PRIMARY KEY,
      campaign_id TEXT NOT NULL,
      donor_name TEXT NOT NULL,
      donor_email TEXT NOT NULL,
      donor_pan TEXT NOT NULL,
      monthly_amount INTEGER NOT NULL,
      frequency TEXT DEFAULT 'MONTHLY',
      start_date TEXT NOT NULL,
      payment_method TEXT NOT NULL,
      status TEXT DEFAULT 'ACTIVE',
      next_charge_date TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (campaign_id) REFERENCES campaigns (id)
    );

    CREATE INDEX IF NOT EXISTS idx_donations_campaign ON donations(campaign_id);
    CREATE INDEX IF NOT EXISTS idx_donations_email ON donations(donor_email);
    CREATE INDEX IF NOT EXISTS idx_milestones_campaign ON milestones(campaign_id);
    CREATE INDEX IF NOT EXISTS idx_fund_ledger_campaign ON fund_ledger(campaign_id);
  `;

  await query.exec(schema);
}

module.exports = {
  db,
  query,
  initSchema
};
