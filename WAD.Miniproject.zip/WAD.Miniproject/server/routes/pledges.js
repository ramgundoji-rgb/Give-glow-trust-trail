const express = require('express');
const router = express.Router();
const pledgeController = require('../controllers/pledgeController');
const { validatePledgePayload } = require('../middleware/validation');

router.get('/', pledgeController.getPledges);
router.post('/', validatePledgePayload, pledgeController.createPledge);
router.patch('/:id/cancel', pledgeController.cancelPledge);

module.exports = router;
