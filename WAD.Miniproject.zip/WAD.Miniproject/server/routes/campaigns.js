const express = require('express');
const router = express.Router();
const campaignController = require('../controllers/campaignController');

router.get('/', campaignController.getAllCampaigns);
router.get('/stats', campaignController.getPlatformStats);
router.get('/:id', campaignController.getCampaignById);

module.exports = router;
