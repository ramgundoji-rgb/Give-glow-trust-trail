const express = require('express');
const router = express.Router();
const donationController = require('../controllers/donationController');
const { validateDonationPayload } = require('../middleware/validation');

router.get('/', donationController.getDonations);
router.post('/', validateDonationPayload, donationController.createDonation);

module.exports = router;
