const express = require('express');
const router = express.Router();
const receiptController = require('../controllers/receiptController');

router.get('/:receiptNo', receiptController.getReceiptByNumber);

module.exports = router;
