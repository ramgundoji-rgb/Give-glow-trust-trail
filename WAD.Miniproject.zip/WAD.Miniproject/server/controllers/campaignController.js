const { query } = require('../db/database');
const { calculateImpactEquivalency } = require('../utils/impactCalculator');

// List campaigns with search, category filtering, and pagination
async function getAllCampaigns(req, res, next) {
  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.max(1, Math.min(50, parseInt(req.query.limit, 10) || 6));
    const offset = (page - 1) * limit;

    const category = req.query.category;
    const search = req.query.search;

    let whereClauses = [];
    let params = [];

    if (category && category !== 'All') {
      whereClauses.push('category = ?');
      params.push(category);
    }

    if (search && search.trim() !== '') {
      whereClauses.push('(title LIKE ? OR description LIKE ? OR location LIKE ?)');
      const term = `%${search.trim()}%`;
      params.push(term, term, term);
    }

    const whereSql = whereClauses.length > 0 ? 'WHERE ' + whereClauses.join(' AND ') : '';

    // Count total matching
    const countRow = await query.get(
      `SELECT COUNT(*) as total FROM campaigns ${whereSql}`,
      params
    );
    const total = countRow ? countRow.total : 0;
    const totalPages = Math.ceil(total / limit) || 1;

    // Fetch campaigns
    const campaigns = await query.all(
      `SELECT * FROM campaigns ${whereSql} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );

    // Calculate percentage progress & attach tiers
    const enhancedCampaigns = await Promise.all(
      campaigns.map(async (c) => {
        const percentage = Math.min(100, Math.round((c.raised_amount / c.goal_amount) * 100));
        const tiers = await query.all(
          'SELECT * FROM donation_tiers WHERE campaign_id = ? ORDER BY amount ASC',
          [c.id]
        );
        return {
          ...c,
          percentage,
          isCompleted: c.raised_amount >= c.goal_amount,
          tiers
        };
      })
    );

    res.json({
      success: true,
      campaigns: enhancedCampaigns,
      pagination: {
        total,
        page,
        limit,
        totalPages,
        hasNext: page < totalPages,
        hasPrev: page > 1
      }
    });
  } catch (err) {
    next(err);
  }
}

// Get single campaign by ID with tiers, ledger, and milestones
async function getCampaignById(req, res, next) {
  try {
    const { id } = req.params;
    const campaign = await query.get('SELECT * FROM campaigns WHERE id = ?', [id]);

    if (!campaign) {
      return res.status(404).json({
        success: false,
        message: `Campaign with ID '${id}' not found.`
      });
    }

    const tiers = await query.all(
      'SELECT * FROM donation_tiers WHERE campaign_id = ? ORDER BY amount ASC',
      [id]
    );

    const ledger = await query.all(
      'SELECT * FROM fund_ledger WHERE campaign_id = ? ORDER BY category ASC, spent_amount DESC',
      [id]
    );

    const milestones = await query.all(
      'SELECT * FROM milestones WHERE campaign_id = ? ORDER BY date DESC',
      [id]
    );

    const percentage = Math.min(100, Math.round((campaign.raised_amount / campaign.goal_amount) * 100));

    res.json({
      success: true,
      campaign: {
        ...campaign,
        percentage,
        tiers,
        ledger,
        milestones
      }
    });
  } catch (err) {
    next(err);
  }
}

// Overall platform summary statistics
async function getPlatformStats(req, res, next) {
  try {
    const totals = await query.get(`
      SELECT 
        COUNT(DISTINCT c.id) as totalCampaigns,
        SUM(c.goal_amount) as totalGoal,
        SUM(c.raised_amount) as totalRaised,
        SUM(c.donor_count) as totalDonations
      FROM campaigns c
    `);

    const milestonesCount = await query.get('SELECT COUNT(*) as totalMilestones, SUM(recipients_count) as totalRecipients FROM milestones');

    res.json({
      success: true,
      stats: {
        totalCampaigns: totals.totalCampaigns || 0,
        totalRaised: totals.totalRaised || 0,
        totalDonations: totals.totalDonations || 0,
        totalMilestones: milestonesCount.totalMilestones || 0,
        totalLivesImpacted: milestonesCount.totalRecipients || 0
      }
    });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getAllCampaigns,
  getCampaignById,
  getPlatformStats
};
