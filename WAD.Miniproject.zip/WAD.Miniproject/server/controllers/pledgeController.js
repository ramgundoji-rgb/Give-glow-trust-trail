const { query } = require('../db/database');
const crypto = require('crypto');

// Create recurring micro-donation pledge
async function createPledge(req, res, next) {
  try {
    const {
      campaignId,
      donorName,
      donorEmail,
      donorPan,
      monthlyAmount,
      frequency,
      paymentMethod
    } = req.body;

    const campaign = await query.get('SELECT * FROM campaigns WHERE id = ?', [campaignId]);
    if (!campaign) {
      return res.status(404).json({
        success: false,
        message: `Campaign '${campaignId}' not found.`
      });
    }

    const pledgeId = `PLG-${Date.now().toString().slice(-6)}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
    const today = new Date();
    const nextMonth = new Date(today.getFullYear(), today.getMonth() + 1, today.getDate());
    const startDateStr = today.toISOString().split('T')[0];
    const nextChargeStr = nextMonth.toISOString().split('T')[0];

    await query.run(
      `INSERT INTO pledges (
        id, campaign_id, donor_name, donor_email, donor_pan, monthly_amount,
        frequency, start_date, payment_method, status, next_charge_date
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE', ?)`,
      [
        pledgeId,
        campaignId,
        donorName,
        donorEmail,
        donorPan,
        monthlyAmount,
        frequency || 'MONTHLY',
        startDateStr,
        paymentMethod || 'UPI AutoPay',
        nextChargeStr
      ]
    );

    res.status(201).json({
      success: true,
      message: 'Monthly micro-donation pledge activated successfully!',
      pledge: {
        id: pledgeId,
        campaignId,
        campaignTitle: campaign.title,
        donorName,
        donorEmail,
        monthlyAmount,
        frequency: frequency || 'MONTHLY',
        startDate: startDateStr,
        nextChargeDate: nextChargeStr,
        status: 'ACTIVE'
      }
    });
  } catch (err) {
    next(err);
  }
}

// Get pledges by donor email
async function getPledges(req, res, next) {
  try {
    const email = req.query.email;
    let whereSql = '';
    let params = [];

    if (email) {
      whereSql = 'WHERE p.donor_email = ?';
      params.push(email.trim().toLowerCase());
    }

    const pledges = await query.all(
      `SELECT p.*, c.title as campaign_title, c.ngo_name
       FROM pledges p
       JOIN campaigns c ON p.campaign_id = c.id
       ${whereSql}
       ORDER BY p.created_at DESC`,
      params
    );

    res.json({
      success: true,
      pledges
    });
  } catch (err) {
    next(err);
  }
}

// Cancel a pledge
async function cancelPledge(req, res, next) {
  try {
    const { id } = req.params;
    const result = await query.run(
      `UPDATE pledges SET status = 'CANCELLED' WHERE id = ?`,
      [id]
    );

    if (result.changes === 0) {
      return res.status(404).json({
        success: false,
        message: `Pledge '${id}' not found.`
      });
    }

    res.json({
      success: true,
      message: 'Pledge cancelled successfully.'
    });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  createPledge,
  getPledges,
  cancelPledge
};
