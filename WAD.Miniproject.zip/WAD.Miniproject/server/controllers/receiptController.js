const { query } = require('../db/database');
const { amountInWords } = require('../utils/numberToWords');
const { formatIndianCurrency } = require('../utils/currency');

// Get formal 80G tax receipt details by receipt number
async function getReceiptByNumber(req, res, next) {
  try {
    const { receiptNo } = req.params;

    const donation = await query.get(
      `SELECT d.*, c.title as campaign_title, c.ngo_name, c.ngo_reg_no, c.ngo_80g_reg, c.location as campaign_location, c.unit_name
       FROM donations d
       JOIN campaigns c ON d.campaign_id = c.id
       WHERE d.receipt_no = ?`,
      [receiptNo]
    );

    if (!donation) {
      return res.status(404).json({
        success: false,
        message: `80G Tax Exemption Receipt '${receiptNo}' not found.`
      });
    }

    const formattedReceipt = {
      receiptNo: donation.receipt_no,
      taxExemptionRef: donation.tax_exemption_ref,
      donationId: donation.id,
      donationDate: donation.created_at,
      donor: {
        name: donation.donor_name,
        email: donation.donor_email,
        phone: donation.donor_phone,
        pan: donation.donor_pan,
        address: donation.donor_address || 'Resident of India'
      },
      campaign: {
        id: donation.campaign_id,
        title: donation.campaign_title,
        ngoName: donation.ngo_name,
        ngoRegNo: donation.ngo_reg_no,
        ngo80gReg: donation.ngo_80g_reg,
        location: donation.campaign_location
      },
      financials: {
        amount: donation.amount,
        amountFormatted: formatIndianCurrency(donation.amount),
        amountInWords: amountInWords(donation.amount),
        paymentMethod: donation.payment_method,
        paymentStatus: donation.payment_status
      },
      impactSummary: donation.impact_summary,
      legalClause: 'Donations to this registered foundation are 50% tax exempt under Section 80G of the Indian Income Tax Act, 1961. This electronic certificate bears unique digital verification metadata issued pursuant to Rule 18AB.',
      qrVerificationData: `GIVEGLOW-VERIFIED:receipt=${donation.receipt_no}&pan=${donation.donor_pan}&amt=${donation.amount}&ngo=${encodeURIComponent(donation.ngo_name)}`
    };

    res.json({
      success: true,
      receipt: formattedReceipt
    });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getReceiptByNumber
};
