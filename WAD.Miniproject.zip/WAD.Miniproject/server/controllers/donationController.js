const { query, db } = require('../db/database');
const { calculateImpactEquivalency } = require('../utils/impactCalculator');
const { amountInWords } = require('../utils/numberToWords');
const crypto = require('crypto');

// Record a new donation with atomic balance update and 80G receipt issuance
async function createDonation(req, res, next) {
  try {
    const {
      campaignId,
      donorName,
      donorEmail,
      donorPhone,
      donorPan,
      donorAddress,
      amount,
      paymentMethod,
      isAnonymous
    } = req.body;

    // Verify campaign exists
    const campaign = await query.get('SELECT * FROM campaigns WHERE id = ?', [campaignId]);
    if (!campaign) {
      return res.status(404).json({
        success: false,
        message: `Campaign '${campaignId}' not found.`
      });
    }

    // Generate unique donation ID and 80G Tax Exemption Receipt Number
    const timestamp = Date.now();
    const randomHex = crypto.randomBytes(3).toString('hex').toUpperCase();
    const donationId = `DON-${timestamp.toString().slice(-6)}-${randomHex}`;
    const receiptNo = `GG-80G-${new Date().getFullYear()}-${randomHex}${Math.floor(100 + Math.random() * 900)}`;
    const taxExemptionRef = `80G/${new Date().getFullYear()}/${campaign.ngo_reg_no.slice(-4)}/${randomHex}`;

    // Calculate tangible impact
    const impact = calculateImpactEquivalency(amount, campaign.unit_cost, campaign.unit_name);
    const impactSummary = impact.deliverableText;

    // Begin database transaction for atomic update
    await query.run('BEGIN TRANSACTION');

    try {
      // 1. Insert donation record
      await query.run(
        `INSERT INTO donations (
          id, campaign_id, donor_name, donor_email, donor_phone, donor_pan,
          donor_address, amount, impact_summary, payment_method, payment_status,
          receipt_no, tax_exemption_ref, is_anonymous, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'SUCCESS', ?, ?, ?, datetime('now'))`,
        [
          donationId,
          campaignId,
          donorName,
          donorEmail,
          donorPhone || '',
          donorPan,
          donorAddress || 'Resident of India',
          amount,
          impactSummary,
          paymentMethod,
          receiptNo,
          taxExemptionRef,
          isAnonymous ? 1 : 0
        ]
      );

      // 2. Increment campaign raised amount and donor count
      await query.run(
        `UPDATE campaigns 
         SET raised_amount = raised_amount + ?,
             donor_count = donor_count + 1
         WHERE id = ?`,
        [amount, campaignId]
      );

      // Commit transaction
      await query.run('COMMIT');
    } catch (txErr) {
      await query.run('ROLLBACK');
      throw txErr;
    }

    // Fetch updated campaign
    const updatedCampaign = await query.get('SELECT * FROM campaigns WHERE id = ?', [campaignId]);
    const updatedPercentage = Math.min(100, Math.round((updatedCampaign.raised_amount / updatedCampaign.goal_amount) * 100));

    res.status(201).json({
      success: true,
      message: 'Donation processed successfully!',
      donation: {
        id: donationId,
        campaignId,
        campaignTitle: campaign.title,
        ngoName: campaign.ngo_name,
        ngo80gReg: campaign.ngo_80g_reg,
        ngoRegNo: campaign.ngo_reg_no,
        donorName,
        donorEmail,
        donorPan,
        donorAddress: donorAddress || 'Resident of India',
        amount,
        amountInWords: amountInWords(amount),
        impactSummary,
        impactDetails: impact,
        paymentMethod,
        receiptNo,
        taxExemptionRef,
        createdAt: new Date().toISOString()
      },
      updatedCampaign: {
        ...updatedCampaign,
        percentage: updatedPercentage
      }
    });
  } catch (err) {
    next(err);
  }
}

// Get paginated donations, optionally filtered by donor email for portfolio
async function getDonations(req, res, next) {
  try {
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.max(1, Math.min(50, parseInt(req.query.limit, 10) || 10));
    const offset = (page - 1) * limit;
    const email = req.query.email;

    let whereSql = '';
    let params = [];

    if (email && email.trim() !== '') {
      whereSql = 'WHERE d.donor_email = ?';
      params.push(email.trim().toLowerCase());
    }

    const countRow = await query.get(
      `SELECT COUNT(*) as total FROM donations d ${whereSql}`,
      params
    );
    const total = countRow ? countRow.total : 0;
    const totalPages = Math.ceil(total / limit) || 1;

    const donations = await query.all(
      `SELECT d.*, c.title as campaign_title, c.ngo_name, c.ngo_80g_reg, c.category, c.unit_name, c.unit_cost
       FROM donations d
       JOIN campaigns c ON d.campaign_id = c.id
       ${whereSql}
       ORDER BY d.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );

    // Compute donor portfolio summary metrics
    let portfolioSummary = null;
    if (email) {
      const summaryRow = await query.get(
        `SELECT 
          COUNT(DISTINCT d.id) as donationCount,
          COUNT(DISTINCT d.campaign_id) as causesSupported,
          SUM(d.amount) as totalContributed
         FROM donations d
         WHERE d.donor_email = ?`,
        [email.trim().toLowerCase()]
      );

      // Estimate cumulative lives impacted across supported causes
      portfolioSummary = {
        donationCount: summaryRow ? summaryRow.donationCount || 0 : 0,
        causesSupported: summaryRow ? summaryRow.causesSupported || 0 : 0,
        totalContributed: summaryRow ? summaryRow.totalContributed || 0 : 0,
        // Approx 1 life per 500 contributed
        estimatedLivesImpacted: summaryRow ? Math.max(1, Math.round((summaryRow.totalContributed || 0) / 450)) : 0
      };
    }

    res.json({
      success: true,
      donations,
      portfolioSummary,
      pagination: {
        total,
        page,
        limit,
        totalPages,
        hasNext: page < totalPages,
        hasPrev: page > 1
      }
    });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  createDonation,
  getDonations
};
