/**
 * Server-Side Validation & Sanitization Middleware
 */

// Simple text sanitizer to strip HTML script tags and harmful markup
function sanitizeString(str) {
  if (typeof str !== 'string') return '';
  return str
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/<[^>]*>/g, '')
    .trim();
}

// Indian PAN validation: 5 uppercase letters, 4 digits, 1 uppercase letter
function isValidPAN(pan) {
  if (!pan || typeof pan !== 'string') return false;
  const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
  return panRegex.test(pan.trim().toUpperCase());
}

// Email validation
function isValidEmail(email) {
  if (!email || typeof email !== 'string') return false;
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email.trim());
}

// Phone number validation (10 digits Indian format)
function isValidPhone(phone) {
  if (!phone) return true; // optional field
  const phoneClean = String(phone).replace(/[\s+-]/g, '');
  return /^[0-9]{10,12}$/.test(phoneClean);
}

// Donation request validator middleware
function validateDonationPayload(req, res, next) {
  const { campaignId, donorName, donorEmail, donorPan, amount, paymentMethod } = req.body;

  const errors = [];

  if (!campaignId || typeof campaignId !== 'string') {
    errors.push('Campaign ID is required.');
  }

  const cleanName = sanitizeString(donorName);
  if (!cleanName || cleanName.length < 2) {
    errors.push('Full donor name is required (minimum 2 characters).');
  }

  if (!donorEmail || !isValidEmail(donorEmail)) {
    errors.push('A valid email address is required for 80G tax receipt delivery.');
  }

  if (!donorPan || !isValidPAN(donorPan)) {
    errors.push('Invalid PAN format. Indian PAN must follow the format: 5 letters, 4 digits, 1 letter (e.g., ABCDE1234F).');
  }

  const numAmount = Number(amount);
  if (isNaN(numAmount) || numAmount < 50 || numAmount > 10000000) {
    errors.push('Donation amount must be between ₹50 and ₹1,00,00,000.');
  }

  const validMethods = ['UPI', 'NetBanking', 'Credit Card', 'Debit Card'];
  if (!paymentMethod || !validMethods.includes(paymentMethod)) {
    errors.push('Please select a valid payment method (UPI, NetBanking, Credit Card, Debit Card).');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors
    });
  }

  // Attach sanitized fields to req.body
  req.body.donorName = cleanName;
  req.body.donorEmail = donorEmail.trim().toLowerCase();
  req.body.donorPan = donorPan.trim().toUpperCase();
  req.body.amount = Math.round(numAmount);
  req.body.donorAddress = sanitizeString(req.body.donorAddress || 'Resident of India');
  req.body.donorPhone = sanitizeString(req.body.donorPhone || '');

  next();
}

// Recurring pledge validator middleware
function validatePledgePayload(req, res, next) {
  const { campaignId, donorName, donorEmail, donorPan, monthlyAmount, paymentMethod } = req.body;

  const errors = [];

  if (!campaignId) errors.push('Campaign ID is required.');
  const cleanName = sanitizeString(donorName);
  if (!cleanName || cleanName.length < 2) errors.push('Donor name is required.');
  if (!donorEmail || !isValidEmail(donorEmail)) errors.push('Valid email is required.');
  if (!donorPan || !isValidPAN(donorPan)) errors.push('Valid PAN is required for tax deduction eligibility.');

  const numAmount = Number(monthlyAmount);
  if (isNaN(numAmount) || numAmount < 100 || numAmount > 500000) {
    errors.push('Monthly pledge amount must be between ₹100 and ₹5,00,000.');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: 'Pledge validation failed',
      errors
    });
  }

  req.body.donorName = cleanName;
  req.body.donorEmail = donorEmail.trim().toLowerCase();
  req.body.donorPan = donorPan.trim().toUpperCase();
  req.body.monthlyAmount = Math.round(numAmount);

  next();
}

module.exports = {
  sanitizeString,
  isValidPAN,
  isValidEmail,
  isValidPhone,
  validateDonationPayload,
  validatePledgePayload
};
